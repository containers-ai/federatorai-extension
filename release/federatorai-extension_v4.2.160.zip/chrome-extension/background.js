var startLoading = false;

chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.clear(()=>{
        console.log("initialize toggle map");
    })
});

const setIcon = (tabId, current_state) => {
    if (current_state) {
        chrome.browserAction.setIcon({path: "favicon_active.png", tabId: tabId});
    } else {
        chrome.browserAction.setIcon({path: "favicon.png", tabId: tabId});
    }
}

const fireEvent = (tabId, event_action) => {
    clearcache();
    chrome.tabs.sendMessage(tabId, {action: event_action});
}

const clearcache = () =>{
    var millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;//7 days
    var oneWeekAgo = (new Date()).getTime() - millisecondsPerWeek;
    chrome.browsingData.remove({
        "since": oneWeekAgo
    }, {
        "cache": true,
    });
    console.log("cache clear")
}

chrome.browserAction.onClicked.addListener( (tab) => {
    let tabId_str = tab.id.toString();
    chrome.storage.local.get(null, (result) =>{
        /*let str = JSON.stringify(result, null, 4);
        console.log(`previous map: ${str}`);*/
        let current_state = result[tabId_str];
        if (current_state === undefined) {
            current_state = false;
            console.log(`tab id ${tab.id} has not enable extension, set default state to false`)
        }
        console.log(`tab id ${tab.id} previous state is ${current_state}`)
        current_state = !current_state;
        setIcon(tab.id, current_state);
        if (current_state) {
            fireEvent(tab.id, "inject");
        } else {
            fireEvent(tab.id, "remove");
        }

        let map = {};
        map[tabId_str] = current_state;
        chrome.storage.local.set(map, () =>{
            console.log(tabId_str + ' is set to ' + current_state);
        });
    });
});

const sleep = (milliseconds) => {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
            break;
        }
    }
};

// Listen navigation update
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    /*let resp = JSON.stringify(changeInfo, null, 4);
    console.log(`onupdate: ${resp}`);*/
    let tabId_str = tabId.toString();
    chrome.storage.local.get(null, (result) =>{
        /*let str = JSON.stringify(result, null, 4);
        console.log(`previous map: ${str}`);*/
        let current_state = result[tabId_str];

        if (tab.url === changeInfo.url) {
            startLoading = true;
        }
        //if (startLoading && changeInfo.status === "complete" && tab.active && current_state) {
        if (changeInfo.status === "complete" && tab.active && current_state) {
            if (tab.url.indexOf("//nks.netapp.io/clusters/detail/") > 0) {
                sleep(2000);
            }
            setIcon(tabId, current_state);
            fireEvent(tabId, "update");
            startLoading = false;
        };
    });
});

chrome.tabs.onRemoved.addListener((tabId, removeInfo) =>{
    tabId_str = tabId.toString();
    chrome.storage.local.get(null, (result) =>{
        /*let str = JSON.stringify(result, null, 4);
        console.log(`previous map: ${str}`);*/
        let current_state = result[tabId_str];
        if (current_state !== undefined) {
            chrome.storage.local.remove(tabId_str, ()=>{
                console.log(`${tabId} removed`);
            });
        };
    });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method === "post_request") {
        fetch(request.url, request.body)
            .then((response) => response.json())
            .then((response) => {
                sendResponse({
                    status: 200,
                    result: response,
                });
            })
            .catch((err) => {
                sendResponse({
                    status: 500,
                    error: err,
                });
            });
        return true;
    } else if (request.method === "parallel_post_request") {
        var requests = request.requests;
        var asyncRequests = []
        for (let i = 0; i < requests.length; i++) {
            let url = requests[i].url
            let body = requests[i].body
            const postRequest = fetch(url, body)
                .then((result) => result.json());
            asyncRequests.push(postRequest);
        }
        Promise.all(asyncRequests)
            .then((results) => {
                sendResponse({
                    status: 200,
                    results: results,
                });
            })
            .catch((err) => {
                sendResponse({
                    status: 500,
                    error: err,
                });
            });
        return true;
    } else if (request.method === "close_window") {
        setIcon(sender.tab.id, false);
        fireEvent(sender.tab.id, "remove");
        let tabId_str = sender.tab.id.toString();
        let map = {};
        map[tabId_str] = false;
        chrome.storage.local.set(map, () =>{
            console.log(tabId_str + ' is set to ' + false);
        });
    }
});
