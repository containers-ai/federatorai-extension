document.addEventListener('DOMContentLoaded', () => {
    chrome.tabs.getSelected(null, (tab) => {
        const tabLink = tab.url;
        if (tabLink.includes('/clusters/new')) {
            $('#content').html('<div class="wrapper">\
        <div class= "part">\
          <h2 class="title">Current</h2>\
          <div>\
            <span class="plan">Plan: </span>\
            <div class="cost-master-plan">Master\
              <span class="tooltip">\
                <div class="cost-master-block">\
                  <b>Region: </b><span id="cost-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="cost-master-nodes">No Data</span><br />\
                  <b>Size: </b><span id="cost-master-size">No Data</span><br />\
                  <b>Disk: </b><span id="cost-master-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="cost-worker-plan">Worker\
              <span class="tooltip">\
                <div class="cost-worker-block">\
                  <b>Region: </b><span id="cost-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="cost-worker-nodes">No Data</span><br />\
                  <b>Size: </b><span id="cost-worker-size">No Data</span><br />\
                  <b>Disk: </b><span id="cost-worker-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price"><span id="cost-per-month">--</span>/month</p>\
        </div>\
        <div class="part">\
          <h2 class="title">Our Recommendation</h2>\
          <div>\
            <span class="plan">Plan: </span>\
            <div class="rec-master-plan">Master\
              <span class="tooltip">\
                <div class="rec-master-block">\
                  <b>Region: </b><span id="rec-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="rec-master-nodes">No Data</span><br />\
                  <b>Size: </b><span id="rec-master-size">No Data</span><br />\
                  <b>Disk: </b><span id="rec-master-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="rec-worker-plan">Worker\
              <span class="tooltip">\
                <div class="rec-worker-block">\
                  <b>Region: </b><span id="rec-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="rec-worker-nodes">No Data</span><br />\
                  <b>Size: </b><span id="rec-worker-size">No Data</span><br />\
                  <b>Disk: </b><span id="rec-worker-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price"><span id="recommendation">--</span>/month</p>\
        </div>\
      </div>');
        }
        if (tabLink.includes('/clusters/detail/')) {
            $('#content').html('<div align=right><img id="close_window" src="images/cross.png" width="12px" height="12px" style="border:1px gray solid"></div>\
        <div id="chartDiv">\
            <div id="cpu-and-memory-chart"></div>\
            <div id="num-of-vms-chart"></div>\
        </div>\
        <img src="images/collapse.png" title="Collapse" id="collapseChart" width="20px" height="20px" style="display:none">\
        <img src="images/expand.png" title="Expand" id="expandChart" width="20px" height="20px" style="display:none">\
        <div id="monthly-cost-chart"></div>\
      ');
            document.getElementById('close_window').addEventListener('click', () => {
                window.close();
            });

            document.getElementById('collapseChart').addEventListener('click', () => {
                obj = document.getElementById('chartDiv');
                collapseImg = document.getElementById('collapseChart');
                expandImg = document.getElementById('expandChart');

                if (!obj) {
                    return true;
                }
                obj.style.display = "none";
                collapseImg.style.display = "none";
                expandImg.style.display = "block";
                return true;
            });

            document.getElementById('expandChart').addEventListener('click', () => {
                obj = document.getElementById('chartDiv');
                collapseImg = document.getElementById('collapseChart');
                expandImg = document.getElementById('expandChart');

                if (!obj) {
                    return true;
                }
                obj.style.display = "block";
                collapseImg.style.display = "block";
                expandImg.style.display = "none";
                return true;
            });
        }

        $('#refresh-button').click().hide();
    });
});

document.getElementById('refresh-button').addEventListener('click', () => {
    function getPathName() {
        const path = window.location.pathname;
        if (path === '/clusters/new') {
            const chooseProvider = document.getElementsByClassName('provider-choices-wrapper layout-wrap layout-row');
            if (chooseProvider.length) return {
                page: 'choose-provider',
                content: null,
            };

            let started = false;
            let triggerFuc = null;
            let provider_raw = document.getElementsByClassName('provider-logo')[0].children[0].classList[0].split('-')[1];
            let os_type_raw = 'Linux';
            let volume_type_raw = 'General Purpose';
            if (provider_raw === 'gce') {
                provider_raw = 'gcp';
                os_type_raw = 'free';
                volume_type_raw = 'CP-COMPUTEENGINE-STORAGE-PD-SSD';
            } else if (provider_raw === 'aws') {
                volume_type_raw = 'General Purpose';
            } else if (provider_raw === 'azure') {
                //TODO: need a mapping accorind to the disk size. Hardcode to standardssd-e6 for testing.
                volume_type_raw = 'standardssd-e6';
            }
            const provider = provider_raw;
            const os_type = os_type_raw;

            const content = {
                provider,
                region: null,
                master: {
                    os_type: os_type,
                    volume_type: volume_type_raw,
                    count: 0,
                    disk: null,
                    size: null,
                },
                worker: {
                    os_type: os_type,
                    volume_type: volume_type_raw,
                    count: 0,
                    disk: null,
                    size: null,
                },
            };

            if (!document.forms['providerConfigModalForm']) {
                // Add page
                const region = document.querySelector('md-item:nth-child(2) > md-item-content > div:nth-child(2) > p').textContent;
                content.region = region;

                const clusterMap = {
                    'Master': 'master',
                    'Masters': 'master',
                    'Worker': 'worker',
                    'Workers': 'worker',
                };

                const elements = document.body.getElementsByClassName('ng-binding ng-scope');
                for (let i = 0; i < elements.length; i++) {
                    for (let j = 0; j < elements[i].children.length; j++) {
                        if (elements[i].children[j].tagName.toUpperCase() === 'NG-PLURALIZE') {
                            const parentNode = elements[i];
                            const children = parentNode.children;
                            const clusterWithCount = children[0].innerText;
                            const count = clusterWithCount.split(' ')[0];
                            const cluster = clusterWithCount.split(' ')[1];
                            const currentObj = content[clusterMap[cluster]];
                            currentObj.count = count;

                            for (const key in children) {
                                if (children.hasOwnProperty(key)) {
                                    const child = children[key];
                                    const innerHTML = child.innerHTML;
                                    if (innerHTML.includes('Size')) {
                                        const size = child.nextSibling.textContent.trim().toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-');
                                        currentObj.disk = size;
                                    }
                                    if (child.getAttribute('ng-if') === 'isRootDiskSizeSupported') {
                                        const diskNode = child.getAttribute('ng-if');
                                        const disk = child.children[0].nextSibling.textContent.trim().replace(/GB/g, '').trim();
                                        currentObj.size = disk;
                                    }
                                }
                            }

                            content[clusterMap[cluster]] = currentObj;
                        }
                    }
                }

                return {
                    page: 'new',
                    content,
                };
            }

            // Edit page
            const form = document.forms['providerConfigModalForm'];
            const editFormElements = form.elements;
            const editSizes = form.getElementsByClassName('ng-scope layout-row')[0];
            const inputs = form.getElementsByClassName('spc-input-container flex-50');

            content.region = form.getElementsByTagName('md-select-value')[2].textContent || null;
            let master_disk = '';
            let master_size = 0;
            let worker_disk = '';
            let worker_size = 0;
            for (let i = 0; i < inputs.length; i++) {
                if (inputs[i].children[0].textContent === 'Master Size') {
                    master_disk = inputs[i].children[1].children[0].textContent.trim();
                } else if (inputs[i].children[0].textContent === 'Worker Size') {
                    worker_disk = inputs[i].children[1].children[0].textContent.trim();
                } else if (inputs[i].children[0].textContent.startsWith('Master Disk Size')) {
                    master_size = inputs[i].children[1].getAttribute('aria-valuenow');
                } else if (inputs[i].children[0].textContent.startsWith('Worker Disk Size')) {
                    worker_size = inputs[i].children[1].getAttribute('aria-valuenow');
                }
            }
            content.master = {
                os_type: os_type,
                volume_type: volume_type_raw,
                count: editFormElements[0].value || 0,
                disk: master_disk.toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-') || null,
                size: master_size || null,
            };
            content.worker = {
                os_type: os_type,
                volume_type: volume_type_raw,
                count: editFormElements[1].value || 0,
                disk: worker_disk.toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-') || null,
                size: worker_size || null,
            };

            return {
                page: 'new',
                content,
            };
        }

        const re = /\/clusters\/detail\/.+/i;
        if (path.match(re)) {
            const region = document.getElementsByClassName('cluster-location')[0].lastChild.textContent;

            let orgName = '';
            const menuChildren = document.getElementsByClassName('org-selection-menu-content')[0].children;
            for (let i = 0; i < menuChildren.length; i++) {
                const child = menuChildren[i];
                if (child.getElementsByTagName('md-icon').length && child.getElementsByClassName('org-name').length) {
                    orgName = child.getElementsByClassName('org-name')[0].textContent;
                }
            }

            return {
                page: 'detail',
                content: {
                    clusterID: path.split('/')[3],
                    orgName,
                    region,
                },
            };
        }
        return {
            page: null,
            content: window.location.pathname,
        };
    }

    chrome.tabs.executeScript({
        file: "jquery-3.3.1.min.js"
    }, () => {
        chrome.tabs.executeScript({
            code: `(${getPathName})();`
        }, (result) => {
            const {
                page = '', content = {}
            } = result[0];
            const api_base = 'http://35.230.105.9:31000/alameter-api/v1';

            if (page === 'new') {
                const {
                    provider,
                    region,
                    master,
                    worker,
                } = content;
                const calculator_data = {
                    [provider]: [{
                            region,
                            instances: {
                                instancetype: master.disk,
                                operatingsystem: master.os_type,
                                preinstalledsw: "NA",
                                instancenum: master.count,
                                period: "1",
                                unit: "month"
                            },
                            storage: [{
                                volumetype: master.volume_type,
                                storagesize: master.size,
                                storagenum: master.count,
                                period: "1",
                                unit: "month"
                            }]
                        },
                        {
                            region,
                            instances: {
                                instancetype: worker.disk,
                                operatingsystem: worker.os_type,
                                preinstalledsw: "NA",
                                instancenum: worker.count,
                                period: "1",
                                unit: "month"
                            },
                            storage: [{
                                volumetype: worker.volume_type,
                                storagesize: worker.size,
                                storagenum: worker.count,
                                period: "1",
                                unit: "month"
                            }],
                        },
                    ],
                };
                const recommender_data = {
                    acceptance: [{
                        "provider": "*"
                    }, ],
                    configuration: {
                        [provider]: [{
                                region,
                                instances: {
                                    instancetype: master.disk,
                                    operatingsystem: master.os_type,
                                    preinstalledsw: "NA",
                                    instancenum: master.count,
                                    period: "1",
                                    unit: "month"
                                },
                                storage: [{
                                    volumetype: master.volume_type,
                                    storagesize: master.size,
                                    storagenum: master.count,
                                    period: "1",
                                    unit: "month"
                                }]
                            },
                            {
                                region,
                                instances: {
                                    instancetype: worker.disk,
                                    operatingsystem: worker.os_type,
                                    preinstalledsw: "NA",
                                    instancenum: worker.count,
                                    period: "1",
                                    unit: "month"
                                },
                                storage: [{
                                    volumetype: worker.volume_type,
                                    storagesize: worker.size,
                                    storagenum: worker.count,
                                    period: "1",
                                    unit: "month"
                                }],
                            },
                        ],
                    }
                };

                function toFixed2(x) {
                    return Number.parseFloat(x).toFixed(2);
                }

                const headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                };
                const method = 'PUT';

                const calculatorBody = JSON.stringify({
                    calculator: [calculator_data],
                });
                fetch(`${api_base}/calculator/`, Object.assign({}, {
                        headers,
                        method,
                        body: calculatorBody
                    }))
                    .then((response) => response.json())
                    .then((result) => {
                        const {
                            calculator = []
                        } = result;
                        if (calculator.length) {
                            const [master, worker] = calculator[0][provider];
                            const {
                                instances: {
                                    instancenum: masterNodes,
                                    displayname: masterType,
                                },
                                region: masterRegion,
                                storage: [{
                                    storagesize: masterSize,
                                }],
                                totalcost: masterTotal,
                            } = master;
                            const {
                                instances: {
                                    instancenum: workerNodes,
                                    displayname: workerType,
                                },
                                region: workerRegion,
                                storage: [{
                                    storagesize: workerSize,
                                }],
                                totalcost: workerTotal,
                            } = worker;

                            $('#cost-master-region').text(masterRegion);
                            $('#cost-master-nodes').text(masterNodes);
                            $('#cost-master-size').text(masterType);
                            $('#cost-master-disk').text(`${masterSize}GB`);

                            $('#cost-worker-region').text(workerRegion);
                            $('#cost-worker-nodes').text(workerNodes);
                            $('#cost-worker-size').text(workerType);
                            $('#cost-worker-disk').text(`${workerSize}GB`);

                            const total = masterTotal + workerTotal || NaN;
                            $('#cost-per-month').text(`\$${toFixed2(total)}`);
                        }
                    });

                const recommendationBody = JSON.stringify({
                    recommender: [recommender_data],
                });
                fetch(`${api_base}/recommendation/jri/`, Object.assign({}, {
                        headers,
                        method,
                        body: recommendationBody
                    }))
                    .then((response) => response.json())
                    .then((result) => {
                        const {
                            recommender = []
                        } = result;
                        const recommenders = Object.assign(...recommender);
                        if (recommender.length) {
                            const [master, worker] = recommenders[provider];
                            const {
                                instances: {
                                    instancenum: masterNodes,
                                    displayname: masterType,
                                },
                                region: masterRegion,
                                storage: [{
                                    storagesize: masterSize,
                                }],
                                totalcost: masterTotal,
                            } = master;
                            const {
                                instances: {
                                    instancenum: workerNodes,
                                    displayname: workerType,
                                },
                                region: workerRegion,
                                storage: [{
                                    storagesize: workerSize,
                                }],
                                totalcost: workerTotal,
                            } = worker;

                            $('#rec-master-region').text(masterRegion);
                            $('#rec-master-nodes').text(masterNodes);
                            $('#rec-master-size').text(masterType);
                            $('#rec-master-disk').text(`${masterSize}GB`);

                            $('#rec-worker-region').text(workerRegion);
                            $('#rec-worker-nodes').text(workerNodes);
                            $('#rec-worker-size').text(workerType);
                            $('#rec-worker-disk').text(`${workerSize}GB`);

                            const total = masterTotal + workerTotal || NaN;
                            $('#recommendation').text(`\$${toFixed2(total)}`);
                        }
                    });
            }

            if (page === 'choose-provider') {
                $('#refresh-button').hide()
                $('#content').html('<div class="info-wrapper">\
          <div class="main-page-add" id="azure">\
            <h2 class="provider">Azure</h2>\
            <div class="main-page-add-body">\
              <p>\
                <b class="title">europe-west: </b>\
                <span class="description">Most choices of VM types</span>\
              </p>\
              <p>\
                <b class="title">usgov-iowa: </b>\
                <span class="description">Lowest average prices of VMs</span>\
              </p>\
              <p>\
                <b class="title">usgov-iowa: </b>\
                <span class="description">Better prices for compute-intensive workloads</span>\
              </p>\
              <p>\
                <b class="title">usgov-iowa: </b>\
                <span class="description">Better prices fo GPU-enabled computing</span>\
              </p>\
            </div>\
          </div>\
          <div class="main-page-add" id="aws">\
            <h2 class="provider">AWS</h2>\
            <div class="main-page-add-body">\
              <p>\
                <b class="title">Asia Pacific (Osaka-Local): </b>\
                <span class="description">Better prices for general purpose workloads</span>\
              </p>\
              <p>\
                <b class="title">AWS GovCloud (US): </b>\
                <span class="description">Better prices for storage optimized workloads</span>\
              </p>\
            </div>\
          </div>\
          <div class="main-page-add" id="gcp">\
            <h2 class="provider">GCP</h2>\
            <div class="main-page-add-body">\
              <p>\
                <b class="title">southamerica-east1: </b>\
                <span class="description">Better prices for memory optimized workloads</span>\
              </p>\
            </div>\
          </div>\
        </div>');
            }

            if (page === 'detail') {
                const headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                };

                const {
                    clusterID,
                    orgName,
                    region
                } = content;

                const calculateHistoricalCost = (historyData) => {
                    const costHistory = {};

                    for (var vendor in historyData) {
                        costHistory[vendor] = [];
                        historyData[vendor].forEach(({
                            vmcost,
                            vmnum,
                            timestamp
                        }) => {
                            const time = timestamp * 1000;
                            costHistory[vendor].push([time, vmcost]);
                        });
                    }
                    return costHistory;
                };

                const calculateHistoricalJITF = (historyData, nowTime) => {
                    const numHistory = {};
                    jitfResource = {};
                    nowHours = nowTime.getUTCHours();
                    nowMinutes = nowTime.getUTCMinutes();
                    nowSeconds = nowTime.getUTCSeconds();
                    for (var vendor in historyData) {
                        endOfDay = 0;
                        maxNodeNum = 0;
                        jitfResource[vendor] = {};
                        numHistory[vendor] = [];
                        for (let i = 0; i < historyData[vendor].length; i++) {
                            const jitfDataTarget = historyData[vendor][i];
                            if (Object.keys(jitfDataTarget).length === 0) {
                                console.log("Empty historical JITF");
                                return numHistory;
                            }
                            for (var key in jitfDataTarget) {
                                const jitfData = jitfDataTarget[key]
                                jitfData.forEach(({
                                    acc_cost,
                                    node_num,
                                    vm_cost,
                                    timestamp,
                                }) => {
                                    if (!(timestamp in jitfResource[vendor])) {
                                        jitfResource[vendor][timestamp] = {};
                                        jitfResource[vendor][timestamp]["acc_cost"] = 0.0;
                                        jitfResource[vendor][timestamp]["node_num"] = 0;
                                        jitfResource[vendor][timestamp]["vm_cost"] = 0;
                                    }
                                    jitfResource[vendor][timestamp]["acc_cost"] += acc_cost;
                                    jitfResource[vendor][timestamp]["node_num"] += node_num;
                                    jitfResource[vendor][timestamp]["vm_cost"] += vm_cost;
                                });
                            }
                        }

                        Object.keys(jitfResource[vendor]).sort().forEach(function(key, idx, array) {
                            const time = key * 1000;
                            if (endOfDay === 0) {
                                let tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                maxNodeNum = 0;
                                totalCost = 0;
                            }
                            if (endOfDay < time) {
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                                timePoint = tmp.getTime();
                                tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                numHistory[vendor].push({
                                    x: timePoint,
                                    y: maxNodeNum,
                                    cost: totalCost,
                                });
                                maxNodeNum = 0;
                                totalCost = 0;
                            } else {
                                maxNodeNum = Math.max(maxNodeNum, jitfResource[vendor][key]["node_num"]);
                                totalCost += jitfResource[vendor][key]["vm_cost"];
                            }
                            if (idx === array.length - 1){
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                                timePoint = tmp.getTime();
                                numHistory[vendor].push({
                                    x: timePoint,
                                    y: maxNodeNum,
                                    cost: totalCost,
                                });
                            }
                        });
                    }
                    return numHistory;
                };

                const calculatePredictedJERI = (predictedData, costHistory, providerMapping, provider, nowTime) => {
                    const jeriPredict = {};
                    jeriResource = {};
                    nowHours = nowTime.getUTCHours();
                    nowMinutes = nowTime.getUTCMinutes();
                    nowSeconds = nowTime.getUTCSeconds();
                    const predictedDatas = Object.assign(...predictedData);
                    for (var vendor in predictedDatas) {
                        endOfDay = 0;
                        maxOndemand = 0;
                        maxRi = 0;
                        totalRiCost = 0;
                        totalOnDemandCost = 0;
                        jeriResource[vendor] = {};
                        jeriPredict[vendor] = {};
                        jeriPredict[vendor]["ondemandPredict"] = [];
                        jeriPredict[vendor]["riPredict"] = [];
                        jeriPredict[vendor]["riCostPredict"] = [];
                        jeriPredict[vendor]["ondemandCostPredict"] = [];
                        jeriPredict[vendor]["accCostPredict"] = {};
                        jeriPredict[vendor]["master"] = [];
                        jeriPredict[vendor]["worker"] = [];
                        jeriPredict[vendor]["region"] = [];
                        let region = "";
                        if (Object.keys(predictedDatas[vendor]).length === 0) {
                            console.log("predicted JERI of", vendor, "is empty");
                            continue;
                        }
                        for (var key in predictedDatas[vendor]) {
                            region = predictedDatas[vendor]["region"];
                            if (key === "region") {
                                continue;
                            } else {
                                const instanceType = key;
                                const jeriVMNum = predictedDatas[vendor][instanceType];
                                jeriVMNum.forEach(({
                                    ri_cost,
                                    ondemand_cost,
                                    acc_cost,
                                    ondemand_num,
                                    ri_num,
                                    timestamp,
                                    master_num,
                                    worker_num,
                                }) => {
                                    if (!(timestamp in jeriResource[vendor])) {
                                        jeriResource[vendor][timestamp] = {};
                                        jeriResource[vendor][timestamp]["ri_cost"] = 0.0;
                                        jeriResource[vendor][timestamp]["ondemand_cost"] = 0.0;
                                        jeriResource[vendor][timestamp]["acc_cost"] = 0.0;
                                        jeriResource[vendor][timestamp]["ondemand_num"] = 0;
                                        jeriResource[vendor][timestamp]["ri_num"] = 0;
                                        jeriResource[vendor][timestamp]["master"] = master_num;
                                        jeriResource[vendor][timestamp]["worker"] = worker_num;
                                        jeriResource[vendor][timestamp]["region"] = region;
                                        jeriResource[vendor][timestamp]["master_instancetype"] = "";
                                        jeriResource[vendor][timestamp]["worker_instancetype"] = "";
                                    }
                                    if ( master_num > 0 && !(jeriResource[vendor][timestamp]["master_instancetype"].includes(instanceType))) {
                                        if (jeriResource[vendor][timestamp]["master_instancetype"] === "") {
                                            jeriResource[vendor][timestamp]["master_instancetype"] = instanceType;
                                        } else {
                                            jeriResource[vendor][timestamp]["master_instancetype"] = `${jeriResource[vendor][timestamp]["master_instancetype"]}, ${instanceType}`;
                                        }
                                    }
                                    if ( worker_num > 0 && !(jeriResource[vendor][timestamp]["worker_instancetype"].includes(instanceType))) {
                                        if (jeriResource[vendor][timestamp]["worker_instancetype"] === "") {
                                            jeriResource[vendor][timestamp]["worker_instancetype"] = instanceType;
                                        } else {
                                            jeriResource[vendor][timestamp]["worker_instancetype"] = `${jeriResource[vendor][timestamp]["worker_instancetype"]}, ${instanceType}`;
                                        }
                                    }
                                    jeriResource[vendor][timestamp]["ri_cost"] += ri_cost;
                                    jeriResource[vendor][timestamp]["ondemand_cost"] += ondemand_cost;
                                    jeriResource[vendor][timestamp]["acc_cost"] += acc_cost;
                                    jeriResource[vendor][timestamp]["ondemand_num"] += ondemand_num;
                                    jeriResource[vendor][timestamp]["ri_num"] += ri_num;
                                });
                            }
                        }


                        Object.keys(jeriResource[vendor]).sort().forEach(function(key, idx, array) {
                            const time = key * 1000;
                            if (endOfDay === 0) {
                                let tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                maxOndemand = 0;
                                maxRi = 0;
                                totalRiCost = 0;
                                totalOnDemandCost = 0;
                            }
                            if (endOfDay < time) {
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                                timePoint = tmp.getTime();
                                tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                jeriPredict[vendor]["ondemandPredict"].push({
                                    x: timePoint,
                                    y: maxOndemand,
                                    cost: totalOnDemandCost,
                                });
                                jeriPredict[vendor]["riPredict"].push({
                                    x: timePoint,
                                    y: maxRi,
                                    cost: totalRiCost,
                                });
                                jeriPredict[vendor]["riCostPredict"].push({
                                    x: timePoint,
                                    y: totalRiCost,
                                    master: jeriResource[vendor][key]["master"],
                                    worker: jeriResource[vendor][key]["worker"],
                                    region: jeriResource[vendor][key]["region"],
                                    ondemand: jeriResource[vendor][key]["ondemand_num"],
                                    ri: jeriResource[vendor][key]["ri_num"],
                                    masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                                    workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                                    provider: providerMapping[vendor],
                                    accCost: lastAccCost,
                                });
                                jeriPredict[vendor]["ondemandCostPredict"].push({
                                    x: timePoint,
                                    y: totalOnDemandCost,
                                    master: jeriResource[vendor][key]["master"],
                                    worker: jeriResource[vendor][key]["worker"],
                                    region: jeriResource[vendor][key]["region"],
                                    ondemand: jeriResource[vendor][key]["ondemand_num"],
                                    ri: jeriResource[vendor][key]["ri_num"],
                                    masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                                    workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                                    provider: providerMapping[vendor],
                                    accCost: lastAccCost,
                                });
                                maxOndemand = 0;
                                maxRi = 0;
                                totalRiCost = 0;
                                totalOnDemandCost = 0;
                            } else {
                                maxOndemand = Math.max(maxOndemand, jeriResource[vendor][key]["ondemand_num"]);
                                maxRi = Math.max(maxRi, jeriResource[vendor][key]["ri_num"]);
                                totalRiCost += jeriResource[vendor][key]["ri_cost"];
                                totalOnDemandCost += jeriResource[vendor][key]["ondemand_cost"];
                                lastAccCost = jeriResource[vendor][key]["acc_cost"];
                            }
                            if (idx === array.length - 1){
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                                timePoint = tmp.getTime();
                                jeriPredict[vendor]["ondemandPredict"].push({
                                    x: timePoint,
                                    y: maxOndemand,
                                    cost: totalOnDemandCost,
                                });
                                jeriPredict[vendor]["riPredict"].push({
                                    x: timePoint,
                                    y: maxRi,
                                    cost: totalRiCost,
                                });
                                jeriPredict[vendor]["riCostPredict"].push({
                                    x: timePoint,
                                    y: totalRiCost,
                                    master: jeriResource[vendor][key]["master"],
                                    worker: jeriResource[vendor][key]["worker"],
                                    region: jeriResource[vendor][key]["region"],
                                    ondemand: jeriResource[vendor][key]["ondemand_num"],
                                    ri: jeriResource[vendor][key]["ri_num"],
                                    masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                                    workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                                    provider: providerMapping[vendor],
                                });
                                jeriPredict[vendor]["ondemandCostPredict"].push({
                                    x: timePoint,
                                    y: totalOnDemandCost,
                                    master: jeriResource[vendor][key]["master"],
                                    worker: jeriResource[vendor][key]["worker"],
                                    region: jeriResource[vendor][key]["region"],
                                    ondemand: jeriResource[vendor][key]["ondemand_num"],
                                    ri: jeriResource[vendor][key]["ri_num"],
                                    masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                                    workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                                    provider: providerMapping[vendor],
                                });
                                jeriPredict[vendor]["accCostPredict"] = {
                                    value: lastAccCost,
                                    master: jeriResource[vendor][key]["master"],
                                    worker: jeriResource[vendor][key]["worker"],
                                    region: jeriResource[vendor][key]["region"],
                                    ondemand: jeriResource[vendor][key]["ondemand_num"],
                                    ri: jeriResource[vendor][key]["ri_num"],
                                    masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                                    workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                                    provider: providerMapping[vendor],
                                }
                            }
                        });
                    }
                    return jeriPredict;
                };

                const calculatePredictedVMCost = (predictedData, costHistory, providerMapping, provider, currentInfo, nowTime) => {
                    const VMCostArray = {};
                    nowHours = nowTime.getUTCHours();
                    nowMinutes = nowTime.getUTCMinutes();
                    nowSeconds = nowTime.getUTCSeconds();
                    for (var vendor in predictedData) {
                        VMCostArray[vendor] = {};
                        VMCostArray[vendor]["vmCost"] = [];
                        VMCostArray[vendor]["accCost"] = {};
                        totalCost = 0;
                        endOfDay = 0;
                        predictedData[vendor].forEach(({
                            vmcost,
                            acc_cost,
                            vmnum,
                            timestamp
                        }, idx, array) => {
                            const time = timestamp * 1000;
                            if (endOfDay === 0) {
                                let tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                totalCost = 0;
                            }
                            if (endOfDay < time) {
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds);
                                timePoint = tmp.getTime();
                                tmp = new Date(time);
                                tmp.setUTCHours(23,59,59);
                                endOfDay = tmp.getTime();
                                VMCostArray[vendor]["vmCost"].push({
                                    x: timePoint,
                                    y: totalCost,// + costOffset,
                                    master: currentInfo.mastersCount,
                                    worker: currentInfo.workersCount,
                                    region: currentInfo.region,
                                    masterInstanceType: currentInfo.masterInstanceType,
                                    workerInstanceType: currentInfo.workerInstanceType,
                                    provider: providerMapping[vendor],
                                });
                                totalCost = 0;
                            } else {
                                totalCost += vmcost;
                                lastAccCost = acc_cost;
                            }
                            if (idx === array.length - 1){
                                let tmp = new Date(endOfDay);
                                tmp.setUTCHours(nowHours, nowMinutes, nowSeconds);
                                timePoint = tmp.getTime();
                                VMCostArray[vendor]["vmCost"].push({
                                    x: timePoint,
                                    y: totalCost,// + costOffset,
                                    master: currentInfo.mastersCount,
                                    worker: currentInfo.workersCount,
                                    region: currentInfo.region,
                                    masterInstanceType: currentInfo.masterInstanceType,
                                    workerInstanceType: currentInfo.workerInstanceType,
                                    provider: providerMapping[vendor],
                                });
                                VMCostArray[vendor]["accCost"] = {
                                    value: lastAccCost,
                                    master: currentInfo.mastersCount,
                                    worker: currentInfo.workersCount,
                                    region: currentInfo.region,
                                    masterInstanceType: currentInfo.masterInstanceType,
                                    workerInstanceType: currentInfo.workerInstanceType,
                                    provider: providerMapping[vendor],
                                };
                            }
                        });
                    }
                    return VMCostArray;
                };

                const setResourceUtilization = (clusterName, provider, historiesWorkload, predictionsWorkload) => {
                    var totalResource = {};
                    var totalCpu = 0.0;
                    var totalMemory = 0.0;

                    const cpuHistory = {};
                    const memHistory = {};

                    const cpuPredict = {};
                    const memPredict = {};

                    const historicalData = historiesWorkload.resource[clusterName];
                    for (var vendor in historicalData) {
                        cpuHistory[vendor] = [];
                        memHistory[vendor] = [];
                        totalResource[vendor] = {};
                        totalCpu = 0.0;
                        totalMemory = 0.0;
                        for (let i = 0; i < historicalData[vendor].length; i++) {
                            const historiesDataTarget = historicalData[vendor][i];
                            const historiesData = historiesDataTarget[Object.keys(historiesDataTarget)[0]].utilization;
                            totalCpu += historiesDataTarget[Object.keys(historiesDataTarget)[0]]["cpu_cores"];
                            totalMemory += historiesDataTarget[Object.keys(historiesDataTarget)[0]]["memory_total"];
                            historiesData.forEach(({
                                cpu,
                                memory,
                                timestamp
                            }) => {
                                if (!(timestamp in totalResource[vendor])) {
                                    totalResource[vendor][timestamp] = {};
                                    totalResource[vendor][timestamp]["cpu"] = 0.0;
                                    totalResource[vendor][timestamp]["memory"] = 0.0;
                                }
                                totalResource[vendor][timestamp]["cpu"] += cpu;
                                totalResource[vendor][timestamp]["memory"] += memory;
                            });
                        }

                        Object.keys(totalResource[vendor]).sort().forEach(function(key) {
                            const time = key * 1000;
                            var Cpu = totalResource[vendor][key]["cpu"] / totalCpu
                            var Memory = totalResource[vendor][key]["memory"] / totalMemory
                            cpuHistory[vendor].push([time, Cpu * 100]);
                            memHistory[vendor].push([time, Memory * 100]);
                        });
                    }

                    totalResource = {};
                    const predictedData = predictionsWorkload.resource[clusterName];
                    for (var vendor in predictedData) {
                        cpuPredict[vendor] = [];
                        memPredict[vendor] = [];
                        totalResource[vendor] = {};
                        totalCpu = 0.0;
                        totalMemory = 0.0;
                        for (let i = 0; i < predictedData[vendor].length; i++) {
                            const predictionDataTarget = predictedData[vendor][i];
                            const predictionData = predictionDataTarget[Object.keys(predictionDataTarget)[0]].utilization;
                            totalCpu += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["cpu_cores"];
                            totalMemory += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["memory_total"];
                            predictionData.forEach(({
                                cpu,
                                memory,
                                timestamp
                            }) => {
                                if (!(timestamp in totalResource[vendor])) {
                                    totalResource[vendor][timestamp] = {};
                                    totalResource[vendor][timestamp]["cpu"] = 0.0;
                                    totalResource[vendor][timestamp]["memory"] = 0.0;
                                }
                                totalResource[vendor][timestamp]["cpu"] += cpu;
                                totalResource[vendor][timestamp]["memory"] += memory;
                            });
                        }

                        Object.keys(totalResource[vendor]).sort().forEach(function(key) {
                            const time = key * 1000;
                            var Cpu = totalResource[vendor][key]["cpu"] / totalCpu
                            var Memory = totalResource[vendor][key]["memory"] / totalMemory
                            cpuPredict[vendor].push([time, Cpu * 100]);
                            memPredict[vendor].push([time, Memory * 100]);
                        });
                    }
                    setCpuMemChart(cpuHistory[provider], memHistory[provider], cpuPredict[provider], memPredict[provider]);
                };

                const setRequiredVMNumbersAndCost = (totalCount, clusterName, provider, currentInfo, historiesVMCost, historiesJITF, predictionsJERI, predictionsVMCost) => {
                    const providerMapping = {
                        "aws": "AWS",
                        "azure": "Azure",
                        "gcp": "GCP",
                    };
                    let nowTime = new Date();
                    const costHistory = calculateHistoricalCost(historiesVMCost.resource[clusterName]);
                    const numHistory = calculateHistoricalJITF(historiesJITF.resource[clusterName], nowTime);
                    const jeriPredict = calculatePredictedJERI(predictionsJERI.resource[clusterName][provider], costHistory, providerMapping, provider, nowTime);
                    const VMCostArray = calculatePredictedVMCost(predictionsVMCost.resource[clusterName], costHistory, providerMapping, provider, currentInfo, nowTime);
                    const currentTime = Date.now();
                    const days = 8;
                    const min = currentTime - (days * 24 * 60 * 60 * 1000) - 1;
                    totalCountSeries = [];
                    for (var t = min; t < currentTime; t += 86400) {
                        totalCountSeries.push([t, totalCount]);
                    }
                    setNumOfVMChart(totalCountSeries, numHistory[provider], jeriPredict[provider]["ondemandPredict"], jeriPredict[provider]["riPredict"]);
                    setMonthlyCostChart(VMCostArray[provider]["accCost"], jeriPredict);
                    collapseImg = document.getElementById('collapseChart');
                    collapseImg.style.display = "block";
                };

                const setMonthlyCostChart = (VMCost, jeriPredict) => {
                    $('#monthly-cost-chart').html('<p style="font-size: 20px; margin:0px; text-align: center; width: 600px;">Cost Analysis for Cloud Services</p>\
                        <div class="wrapper-in-detail">\
                        <div class= "part-in-detail">\
                          <h3 class="title-in-detail">Current</h3>\
                          <div>\
                            <span class="plan-in-detail">Plan: </span>\
                            <div class="currently-cost-master-plan">Master\
                              <span class="tooltip">\
                                <div class="currently-cost-master-block">\
                                  <b>Region: </b><span id="currently-cost-master-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="currently-cost-master-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="currently-cost-master-size">No Data</span><br />\
                                  <b>Disk: </b><span id="currently-cost-master-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                            <div class="currently-cost-worker-plan">Worker\
                              <span class="tooltip">\
                                <div class="currently-cost-worker-block">\
                                  <b>Region: </b><span id="currently-cost-worker-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="currently-cost-worker-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="currently-cost-worker-size">No Data</span><br />\
                                  <b>Disk: </b><span id="currently-cost-worker-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                          </div>\
                          <p class="price-in-detail"><span id="currently-cost-per-month">--</span><b>/month</b></p>\
                        </div>\
                        <div class="part-in-detail">\
                          <h3 class="title-in-detail" id="first-title">First</h3>\
                          <div>\
                            <span class="plan-in-detail">Plan: </span>\
                            <div class="first-rec-master-plan">Master\
                              <span class="tooltip">\
                                <div class="first-rec-master-block">\
                                  <b>Region: </b><span id="first-rec-master-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="first-rec-master-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="first-rec-master-size">No Data</span><br />\
                                  <b>Disk: </b><span id="first-rec-master-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                            <div class="first-rec-worker-plan">Worker\
                              <span class="tooltip">\
                                <div class="first-rec-worker-block">\
                                  <b>Region: </b><span id="first-rec-worker-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="first-rec-worker-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="first-rec-worker-size">No Data</span><br />\
                                  <b>Disk: </b><span id="first-rec-worker-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                          </div>\
                          <p class="price-in-detail"><span id="first-recommendation">--</span><b>/month</b></p>\
                        </div>\
                        <div class="part-in-detail">\
                          <h3 class="title-in-detail" id="second-title">Second</h3>\
                          <div>\
                            <span class="plan-in-detail">Plan: </span>\
                            <div class="second-rec-master-plan">Master\
                              <span class="tooltip">\
                                <div class="second-rec-master-block">\
                                  <b>Region: </b><span id="second-rec-master-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="second-rec-master-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="second-rec-master-size">No Data</span><br />\
                                  <b>Disk: </b><span id="second-rec-master-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                            <div class="second-rec-worker-plan">Worker\
                              <span class="tooltip">\
                                <div class="second-rec-worker-block">\
                                  <b>Region: </b><span id="second-rec-worker-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="second-rec-worker-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="second-rec-worker-size">No Data</span><br />\
                                  <b>Disk: </b><span id="second-rec-worker-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                          </div>\
                          <p class="price-in-detail"><span id="second-recommendation">--</span><b>/month</b></p>\
                        </div>\
                        <div class="part-in-detail">\
                          <h3 class="title-in-detail" id="third-title">Third</h3>\
                          <div>\
                            <span class="plan-in-detail">Plan: </span>\
                            <div class="third-rec-master-plan">Master\
                              <span class="tooltip">\
                                <div class="third-rec-master-block">\
                                  <b>Region: </b><span id="third-rec-master-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="third-rec-master-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="third-rec-master-size">No Data</span><br />\
                                  <b>Disk: </b><span id="third-rec-master-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                            <div class="third-rec-worker-plan">Worker\
                              <span class="tooltip">\
                                <div class="third-rec-worker-block">\
                                  <b>Region: </b><span id="third-rec-worker-region">No Data</span><br />\
                                  <b>Node(s): </b><span id="third-rec-worker-nodes">No Data</span><br />\
                                  <b>Size: </b><span id="third-rec-worker-size">No Data</span><br />\
                                  <b>Disk: </b><span id="third-rec-worker-disk">No Data</span><br />\
                                </div>\
                              </span>\
                            </div>\
                          </div>\
                          <p class="price-in-detail"><span id="third-recommendation">--</span><b>/month</b></p>\
                        </div>\
                      </div>');
                    awsAccCost = {};
                    gcpAccCost = {};
                    azureAccCost = {};
                    if ("aws" in jeriPredict && "accCostPredict" in jeriPredict["aws"]) {
                        awsAccCost = jeriPredict["aws"]["accCostPredict"];
                    }
                    if ("gcp" in jeriPredict && "accCostPredict" in jeriPredict["gcp"]) {
                        gcpAccCost = jeriPredict["gcp"]["accCostPredict"];
                    }
                    if ("azure" in jeriPredict && "accCostPredict" in jeriPredict["azure"]) {
                        azureAccCost = jeriPredict["azure"]["accCostPredict"];
                    }
                    accCostArray = [];
                    accCostArray.push(awsAccCost);
                    accCostArray.push(gcpAccCost);
                    accCostArray.push(azureAccCost);
                    accCostArray.sort(function(x, y) {
                        if (x["value"] < y["value"]) {
                            return -1;
                        }
                        if (x["value"] > y["value"]) {
                            return 1;
                        }
                        return 0;
                    });

                    $("#currently-cost-master-region").text(VMCost["region"]);
                    $("#currently-cost-worker-region").text(VMCost["region"]);
                    $("#currently-cost-master-nodes").text(VMCost["master"]);
                    $("#currently-cost-worker-nodes").text(VMCost["worker"]);
                    $("#currently-cost-master-size").text(VMCost["masterInstanceType"]);
                    $("#currently-cost-worker-size").text(VMCost["workerInstanceType"]);
                    const total = Number.parseFloat(VMCost["value"] / 7 / 24 * 730).toFixed(2)|| NaN
                    $("#currently-cost-per-month").text("$" + total);
                    setRecommendation("first", accCostArray[0]);
                    setRecommendation("second", accCostArray[1]);
                    setRecommendation("third", accCostArray[2]);
                };

                const setRecommendation = (prefix, recommendation) => {
                    $(`#${prefix}-title`).text(recommendation["provider"]);
                    $(`#${prefix}-rec-master-region`).text(recommendation["region"]);
                    $(`#${prefix}-rec-worker-region`).text(recommendation["region"]);
                    $(`#${prefix}-rec-master-nodes`).text(recommendation["master"]);
                    $(`#${prefix}-rec-worker-nodes`).text(recommendation["worker"]);
                    $(`#${prefix}-rec-master-size`).text(recommendation["masterInstancetype"]);
                    $(`#${prefix}-rec-worker-size`).text(recommendation["workerInstancetype"]);
                    const total = Number.parseFloat(recommendation["value"] / 7 / 24 * 730).toFixed(2)|| NaN;
                    $(`#${prefix}-recommendation`).text("$" + total);
                };

                const setCostChart = (VMCostArray, jeriPredict) => {
                    const currentTime = Date.now();
                    const days = 7;
                    //const min = currentTime - (days * 24 * 60 * 60 * 1000);
                    const min = currentTime;
                    const max = currentTime + (days * 24 * 60 * 60 * 1000);

                    awsRiCostArray = [];
                    awsOndemandCostArray = [];
                    gcpRiCostArray = [];
                    gcpOndemandCostArray = [];
                    azureRiCostArray = [];
                    azureOndemandCostArray = [];
                    if ("aws" in jeriPredict && "riCostPredict" in jeriPredict["aws"]) {
                        awsRiCostArray = jeriPredict["aws"]["riCostPredict"];
                    }
                    if ("aws" in jeriPredict && "ondemandCostPredict" in jeriPredict["aws"]) {
                        awsOndemandCostArray = jeriPredict["aws"]["ondemandCostPredict"];
                    }
                    if ("gcp" in jeriPredict && "riCostPredict" in jeriPredict["gcp"]) {
                        gcpRiCostArray = jeriPredict["gcp"]["riCostPredict"];
                    }
                    if ("gcp" in jeriPredict && "ondemandCostPredict" in jeriPredict["gcp"]) {
                        gcpOndemandCostArray = jeriPredict["gcp"]["ondemandCostPredict"];
                    }
                    if ("azure" in jeriPredict && "riCostPredict" in jeriPredict["azure"]) {
                        azureRiCostArray = jeriPredict["azure"]["riCostPredict"];
                    }
                    if ("azure" in jeriPredict && "ondemandCostPredict" in jeriPredict["azure"]) {
                        azureOndemandCostArray = jeriPredict["azure"]["ondemandCostPredict"];
                    }
                    $('#cost-chart').highcharts({
                        chart: {
                            height: 187,
                            width: 600,
                            type: 'column',
                            plotBorderWidth: 1,
                            marginRight: 10,
                        },
                        title: {
                            margin: 0,
                            text: 'Recommendation for Cluster Migration',
                        },
                        xAxis: {
                            type: 'datetime',
                            tickPixelInterval: 80,
                            min,
                            max,
                        },
                        yAxis: {
                            title: {
                                text: null,
                            },
                            labels: {
                                format: '${value}',
                            },
                            plotLines: [{
                                value: 0,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            //shared: true,
                            crosshairs: true,
                            useHTML: true,
                            //pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: <b>{point.y:.2f}</b>',
                            /*headerFormat:
                              '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                              '<b>{point.point.symbolName}</b><br>',*/
                        },
                        legend: {
                            margin: 2,
                            align: 'left',
                            verticalAlign: 'top',
                            borderWidth: 0,
                        },
                        exporting: {
                            enabled: false
                        },
                        plotOptions: {
                            column: {
                                stacking: 'normal',
                                pointPadding: 0,
                                groupPadding: 0.05,
                                pointWidth: 15,
                            }
                        },
                        series: [
                            /*{
                              color: '#ea214c',
                              name: 'Accumulated Cost',
                              data: history,
                              display: 'block',
                            },*/
                            {
                                color: '#00bfff',
                                name: 'Current',
                                //dashStyle: 'ShortDot',
                                data: VMCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstanceType}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstanceType}</b><br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name}: <b>{point.y:.2f}</b><br/></b>',
                                },
                                stack: 'Current',
                            },
                            /*{
                              name: 'JIFT Cost',
                              color: '#aa5cc7',
                              dashStyle: 'ShortDot',
                              data: jitfArray,
                              display: 'none',
                            },*/
                            {
                                name: 'GCP',
                                color: '#8cd79a',
                                dashStyle: 'ShortDot',
                                data: gcpOndemandCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'GCP',
                            },
                            {
                                name: 'GCP',
                                linkedTo: ':previous',
                                color: '#2c8b3e',
                                dashStyle: 'ShortDot',
                                data: gcpRiCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'GCP',
                            },
                            {
                                name: 'AWS',
                                color: '#c27bdf',
                                dashStyle: 'ShortDot',
                                data: awsOndemandCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'AWS',
                            },
                            {
                                name: 'AWS',
                                linkedTo: ':previous',
                                color: '#a843d2',
                                dashStyle: 'ShortDot',
                                data: awsRiCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'AWS',
                            },
                            {
                                name: 'Azure',
                                color: '#f1c673',
                                dashStyle: 'ShortDot',
                                data: azureOndemandCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'Azure',
                            },
                            {
                                name: 'Azure',
                                linkedTo: ':previous',
                                color: '#ecae37',
                                dashStyle: 'ShortDot',
                                data: azureRiCostArray,
                                display: 'none',
                                tooltip: {
                                    headerFormat: '',
                                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                                },
                                stack: 'Azure',
                            },
                        ],
                    });
                };

                const setCpuMemChart = (cpuHistory, memHistory, cpuPredict, memPredict) => {
                    const currentTime = Date.now();
                    const days = 7;
                    const min = currentTime - (days * 24 * 60 * 60 * 1000);
                    const max = currentTime + (days * 24 * 60 * 60 * 1000);
                    plotLineId = 'clusterCapacityLine'
                    plotLineOptions = {
                        id: plotLineId,
                        value: 100,
                        width: 2,
                        dashStyle: 'ShortDash',
                        color: '#5cc770',
                        label: {
                            text: 'Cluster Capacity',
                            y: 20
                        },
                        zIndex: 1,
                    };
                    $('#cpu-and-memory-chart').highcharts({
                        chart: {
                            height: 187,
                            width: 600,
                            type: 'spline',
                            plotBorderWidth: 1,
                            marginRight: 10,
                        },
                        title: {
                            margin: 0,
                            text: 'Resource Utilization for Managed Pods',
                        },
                        xAxis: {
                            type: 'datetime',
                            tickPixelInterval: 80,
                            plotLines: [{
                                color: '#23b0a2',
                                width: 2,
                                dashStyle: 'ShortDash',
                                label: {
                                    text: 'Now',
                                },
                                value: new Date().getTime(),
                                zIndex: 5,
                            }],
                            min,
                            max,
                        },
                        yAxis: [{
                            labels: {
                                format: '{value} %',
                            },
                            title: {
                                text: null,
                            },
                            maxPadding: 0,
                            plotLines: [],
                            tickAmount: 6,
                        }],
                        tooltip: {
                            shared: true,
                            crosshairs: true,
                            useHTML: true,
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:.2f} %</b><br/>',
                            headerFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                                '<b>{point.point.symbolName}</b><br>',
                        },
                        legend: {
                            margin: 2,
                            align: 'left',
                            verticalAlign: 'top',
                            borderWidth: 0,
                            itemDistance: 10,
                        },
                        exporting: {
                            enabled: false
                        },
                        series: [{
                                color: '#0086b3',
                                name: 'CPU',
                                tooltip: {
                                    valueSuffix: ' %'
                                },
                                data: cpuHistory,
                                display: 'block',
                                marker: {
                                    symbol: "circle"
                                }
                            },
                            {
                                color: '#00bfff',
                                name: 'Memory',
                                tooltip: {
                                    valueSuffix: ' %'
                                },
                                data: memHistory,
                                display: 'block',
                                marker: {
                                    symbol: "diamond"
                                }
                            },
                            {
                                color: '#e22e5d',
                                name: 'CPU Predicted',
                                tooltip: {
                                    valueSuffix: ' %'
                                },
                                dashStyle: 'ShortDot',
                                data: cpuPredict,
                                display: 'none',
                                marker: {
                                    symbol: "circle"
                                }
                            },
                            {
                                color: '#fc7095',
                                name: 'Memory Predicted',
                                tooltip: {
                                    valueSuffix: ' %'
                                },
                                dashStyle: 'ShortDot',
                                data: memPredict,
                                display: 'none',
                                marker: {
                                    symbol: "diamond"
                                }
                            },
                            {
                                color: '#5cc770',
                                name: 'Cluster Capacity',
                                marker: {
                                    enabled: false
                                },
                                dashStyle: 'ShortDash',
                                events: {
                                    // Event for showing/hiding plot line
                                    legendItemClick: function(e) {
                                        if (this.visible) {
                                            this.chart.yAxis[0].removePlotLine(plotLineId);
                                            this.chart.yAxis[0].setExtremes(null, null);
                                        } else {
                                            this.chart.yAxis[0].addPlotLine(plotLineOptions);
                                            this.chart.yAxis[0].setExtremes(null, 100);
                                        }
                                    },
                                    afterAnimate: function() {
                                        this.chart.yAxis[0].addPlotLine(plotLineOptions);
                                        this.chart.yAxis[0].setExtremes(null, 100);
                                    }
                                }
                            },
                        ],
                    });
                };

                const setNumOfVMChart = (totalCountSeries, numHistory, ondemandPredict, riPredict) => {
                    const currentTime = Date.now();
                    const days = 8;
                    const min = currentTime - (days * 24 * 60 * 60 * 1000);
                    const max = currentTime + (days * 24 * 60 * 60 * 1000);

                    $('#num-of-vms-chart').highcharts({
                        chart: {
                            height: 187,
                            width: 600,
                            type: 'column',
                            plotBorderWidth: 1,
                            marginRight: 10,
                        },
                        title: {
                            margin: 0,
                            text: 'Recommendation for Reserved Instance Commitments',
                        },
                        xAxis: {
                            type: 'datetime',
                            tickPixelInterval: 160,
                            plotLines: [{
                                color: '#23b0a2',
                                width: 2,
                                dashStyle: 'ShortDash',
                                label: {
                                    text: 'Now'
                                },
                                value: new Date().getTime(),
                                zIndex: 5,
                            }],
                            min,
                            max,
                            minPadding: 0,
                            maxPadding: 0,
                        },
                        yAxis: {
                            title: {
                                text: null,
                            },
                            /*plotLines: [{
                                value: totalCount,
                                width: 3,
                                color: '#5cc770',
                                dashStyle: 'ShortDash',
                                label: {
                                    text: 'Cluster Allocated',
                                    y: 20,
                                }
                            }],*/
                            tickInterval: 2,
                            allowDecimals: false,
                        },
                        tooltip: {
                            shared: true,
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} node(s), ${point.cost:.2f}/day</b><br/>',
                            /*formatter: function() {
                                var pformat = '';
                                var totalCost = 0;
                                this.points.forEach((point) => {
                                    pformat += '<b><span style="color: ' + point.series.color + '">' + point.series.name + '</span>: <b>' + point.y + ' node(s)</b></b><br/>';
                                    totalCost += point.point.cost;
                                });
                                pformat += '<b>$<b>' + Number.parseFloat(totalCost).toFixed(2) + '</b>/day</b><br/>';
                                return pformat;
                            },*/
                        },
                        legend: {
                            margin: 2,
                            align: 'left',
                            verticalAlign: 'top',
                            borderWidth: 0
                        },
                        exporting: {
                            enabled: false
                        },
                        series: [{
                                color: '#00bfff',
                                name: 'Observed',
                                data: numHistory,
                                stack: 'observed',
                                stacking: 'normal',
                                pointWidth: 20,
                            },
                            {
                                color: '#e0896c',
                                name: 'On-demand',
                                data: ondemandPredict,
                                stack: 'predicted',
                                stacking: 'normal',
                                pointWidth: 20,
                            },
                            {
                                name: 'Reserved Instance',
                                color: '#d3572d',
                                data: riPredict,
                                stack: 'predicted',
                                stacking: 'normal',
                                pointWidth: 20,
                            },
                            {
                                color: '#5cc770',
                                type: 'spline',
                                data: totalCountSeries,
                                dashStyle: 'ShortDash',
                                display: 'none',
                                name: 'Cluster Allocated',
                                marker : {
                                    enabled: false
                                },
                                enableMouseTracking: false,
                            }
                        ],
                    });
                }

                const setDetialView = (data, provider, public_api, currentInfo) => {
                    const api = `${public_api}/resource/`;
                    const method = 'PUT';

                    // Historical Workload
                    const historyUtilization = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'historical',
                                type: 'workload',
                            })
                        ],
                    });
                    const historicalWorkload = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: historyUtilization
                        }))
                        .then((result) => result.json());

                    // Predicted Workload
                    const predictedUtilization = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'predicted',
                                type: 'workload',
                            })
                        ],
                    });
                    const predictedWorkload = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: predictedUtilization
                        }))
                        .then((result) => result.json());

                    // Historical VMCost
                    const historyVMCost = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'historical',
                                type: 'vmcost'
                            })
                        ],
                    });
                    const historicalVMCost = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: historyVMCost
                        }))
                        .then((result) => result.json());

                    // Historical JITF
                    const historyJITF = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'historical',
                                type: 'jitf'
                            })
                        ],
                    });
                    const historicalJITF = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: historyJITF
                        }))
                        .then((result) => result.json());

                    // Predicted JERI
                    const predictedJERIVMNum = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'predicted',
                                type: 'jeri'
                            })
                        ],
                    });
                    const predictedJERI = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: predictedJERIVMNum
                        }))
                        .then((result) => result.json());

                    // Predicted VMCost
                    const predictedVMCostData = JSON.stringify({
                        resource: [
                            Object.assign({}, data, {
                                category: 'predicted',
                                type: 'vmcost'
                            })
                        ],
                    });
                    const predictedVMCost = fetch(api, Object.assign({}, {
                            headers,
                            method,
                            body: predictedVMCostData
                        }))
                        .then((result) => result.json());

                    var historiesWorkload = {};
                    var predictionsWorkload = {};
                    var historiesVMCost = {};
                    var historiesJITF = {};
                    var predictionsJERI = {};
                    var predictionsVMCost = {};
                    Promise.all([
                            historicalWorkload,
                            predictedWorkload,
                            historicalVMCost,
                            historicalJITF,
                            predictedJERI,
                            predictedVMCost,
                        ])
                        .then((results) => {
                            console.log("Query Response from API successfully");
                            historiesWorkload = results[0];
                            predictionsWorkload = results[1];
                            historiesVMCost = results[2];
                            historiesJITF = results[3];
                            predictionsJERI = results[4];
                            predictionsVMCost = results[5];
                            const totalCount = data.nodesinfo[Object.keys(data.nodesinfo)[0]].length;
                            const clusterName = data.clustername;
                            setResourceUtilization(clusterName, provider, historiesWorkload, predictionsWorkload);
                            setRequiredVMNumbersAndCost(totalCount, clusterName, provider, currentInfo, historiesVMCost, historiesJITF, predictionsJERI, predictionsVMCost);
                        })
                        .catch((err) => {
                            console.log(err);
                            console.log("Error occurred during setDetialView");
                            const jeriEmpty = {
                                gcp: {
                                    riCostPredict: [],
                                    ondemandCostPredict: []
                                },
                                aws: {
                                    riCostPredict: [],
                                    ondemandCostPredict: []
                                },
                                azure: {
                                    riCostPredict: [],
                                    ondemandCostPredict: []
                                }
                            };
                            setCostChart([], jeriEmpty);
                            setCpuMemChart([], [], [], []);
                            setNumOfVMChart(0, [], [], []);
                        });
                }

                const cluster = async () => {
                    const fetchOrgID = await fetch('https://api.nks.netapp.io/orgs', Object.assign({}, {
                        headers,
                        method: 'GET'
                    }));
                    const resultOrgID = await fetchOrgID.json();
                    const orgID = resultOrgID.filter(({
                        name
                    }) => name === orgName)[0].pk;
                    const fetchCluster = await fetch(`https://api.nks.netapp.io/orgs/${orgID}/clusters`, Object.assign({}, {
                        headers,
                        method: 'GET'
                    }));
                    const resultCluster = await fetchCluster.json();

                    return resultCluster.filter(({
                        pk
                    }) => pk === Number(clusterID))[0];
                };

                /*$('#cpu-and-memory-chart').html('<p style="font-size: 12px; text-align: center; width: 600px;">Loading Resource Utilization for Managed Pods Chart...</p>');
                $('#num-of-vms-chart').html('<p style="font-size: 12px; text-align: center; width: 600px;">Loading Required VM Numbers for Managed Pods Chart...</p>');
                $('#cost-chart').html('<p style="font-size: 12px; text-align: center; width: 600px;">Loading Accumulated Costs for Current and Recommended Plans Chart...</p>');*/
                $('#cpu-and-memory-chart').html('<img src="images/loading2.gif">');

                cluster()
                    .then(({
                        name = '',
                        provider = 'aws',
                        nodes = []
                    }) => {
                        let volume_type_raw = 'General Purpose';
                        let os_type_raw = 'Linux';
                        if (provider === 'gce') {
                            provider = 'gcp';
                            os_type_raw = 'free';
                            volume_type_raw = 'CP-COMPUTEENGINE-STORAGE-PD-CAPACITY';
                        } else if (provider === 'aws') {
                            volume_type_raw = 'General Purpose';
                        } else if (provider === 'azure') {
                            volume_type_raw = 'standardssd-e6';
                        }
                        const data = {
                            name,
                            provider,
                            region,
                            masters: [],
                            workers: [],
                        };

                        const masters = nodes.filter(({
                            role
                        }) => role === 'master');
                        const workers = nodes.filter(({
                            role
                        }) => role === 'worker');
                        const mastersCount = masters.length;
                        const workersCount = workers.length;
                        let public_api = `${api_base}`;
                        if (masters.length > 0) {
                            const public_ip = masters[0].public_ip;
                            public_api = `http://${public_ip}:31000/alameter-api/v1`;
                        }

                        masters.forEach(({
                            public_ip,
                            private_ip,
                            instance_id,
                            root_disk_size,
                            size,
                        }) => {
                            let nodename = instance_id;
                            if (provider === 'aws') {
                                nodename = private_ip;
                            }
                            data.masters.push({
                                host: public_ip,
                                nodename: nodename,
                                instancetype: size.replace(/\s+/g, '-').replace(/\_/g, '-'),
                                instancenum: mastersCount,
                                storagesize: root_disk_size,
                                storagenum: mastersCount,
                                volume_type: volume_type_raw,
                                os_type: os_type_raw,
                            });
                        });
                        workers.forEach(({
                            public_ip,
                            private_ip,
                            instance_id,
                            root_disk_size,
                            size,
                        }) => {
                            let nodename = instance_id;
                            if (provider === 'aws') {
                                nodename = private_ip;
                            }
                            data.workers.push({
                                host: public_ip,
                                nodename: nodename,
                                instancetype: size.replace(/\s+/g, '-').replace(/\_/g, '-'),
                                //instancenum: workersCount,
                                instancenum: "1",
                                storagesize: root_disk_size,
                                //storagenum: workersCount,
                                storagenum: "1",
                                volume_type: volume_type_raw,
                                os_type: os_type_raw,
                            });
                        });

                        data.host = data.masters.map(({
                            host
                        }) => host);
                        return {
                            data: data,
                            public_api: public_api,
                        };
                    })
                    .then((result) => {
                        const {
                            data,
                            public_api,
                        } = result;
                        const {
                            host,
                            masters,
                            name,
                            provider,
                            region,
                            workers,
                        } = data;

                        const nodesInfo = [];
                        masters.forEach((master) => {
                            const {
                                nodename,
                                instancetype,
                                instancenum,
                                storagesize,
                                storagenum,
                                volume_type,
                                os_type,
                            } = master;
                            const obj = {
                                region,
                                instances: {
                                    nodename: nodename.split('.').join('-'),
                                    instancetype,
                                    nodetype: "master",
                                    operatingsystem: os_type,
                                    preinstalledsw: "NA",
                                    instancenum: String(instancenum),
                                    period: "1",
                                    unit: "hour"
                                },
                                storage: [{
                                    volumetype: volume_type,
                                    storagesize: String(storagesize),
                                    storagenum: String(storagenum),
                                    period: "1",
                                    unit: "hour",
                                }],
                            };
                            nodesInfo.push(obj);
                        });
                        workers.forEach((worker) => {
                            const {
                                nodename,
                                instancetype,
                                instancenum,
                                storagesize,
                                storagenum,
                                volume_type,
                                os_type,
                            } = worker;
                            const obj = {
                                region,
                                instances: {
                                    nodename: nodename.split('.').join('-'),
                                    instancetype,
                                    nodetype: "worker",
                                    operatingsystem: os_type,
                                    preinstalledsw: "NA",
                                    instancenum: String(instancenum),
                                    period: "1",
                                    unit: "hour"
                                },
                                storage: [{
                                    volumetype: volume_type,
                                    storagesize: String(storagesize),
                                    storagenum: String(storagenum),
                                    period: "1",
                                    unit: "hour",
                                }],
                            };
                            nodesInfo.push(obj);
                        });

                        const resources = {
                            category: "",
                            type: "",
                            clustername: name,
                            /*host,
                            port: "30537",*/
                            nodesinfo: {
                                [provider]: nodesInfo,
                            },
                        };

                        return {
                            data: resources,
                            provider: provider,
                            public_api: public_api,
                            mastersCount: masters.length,
                            workersCount: workers.length,
                            region: region,
                            masterInstanceType: masters[0].instancetype,
                            workerInstanceType: workers[0].instancetype,
                        };
                    })
                    .then((result) => {
                        const {
                            data,
                            provider,
                            public_api,
                            mastersCount,
                            workersCount,
                            region,
                            masterInstanceType,
                            workerInstanceType,
                        } = result;

                        const currentInfo = {
                            mastersCount: mastersCount,
                            workersCount: workersCount,
                            masterInstanceType: masterInstanceType,
                            workerInstanceType: workerInstanceType,
                            region: region,
                        };
                        setDetialView(data, provider, public_api, currentInfo);
                    });
            }
        });
    });
});
