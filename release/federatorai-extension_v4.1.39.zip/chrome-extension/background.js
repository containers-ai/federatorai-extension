var toggleMap = {};
var startLoading = false;
const checkIcon = (tabId) => {
    if (toggleMap[tabId]) {
        chrome.browserAction.setIcon({path: "favicon_active.png", tabId: tabId});
        chrome.tabs.sendMessage(tabId, {action: "inject"});
    } else {
        
        chrome.browserAction.setIcon({path: "favicon.png", tabId: tabId});
        clearcache();
        chrome.tabs.sendMessage(tabId, {action: "remove"});
    }
}

const clearcache = () =>{
    var millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;//7 days
    var oneWeekAgo = (new Date()).getTime() - millisecondsPerWeek;
    chrome.browsingData.remove({
        "since": oneWeekAgo
    }, {        
        "cache": true,        
    });    
    console.log("cache clear")
}

chrome.browserAction.onClicked.addListener( (tab) => {
    if (!tab.id in toggleMap) {
        toggleMap[tab.id] = false;
    }
    toggleMap[tab.id] = !toggleMap[tab.id];
    checkIcon(tab.id);
});

const sleep = (milliseconds) => {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
            break;
        }
    }
};

// Listen navigation update
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.url === changeInfo.url) {
        startLoading = true;
    }
    if (startLoading && changeInfo.status === "complete" && tab.active && toggleMap[tabId]) {
        if (tab.url.indexOf("//nks.netapp.io/clusters/detail/") > 0) {
            sleep(2000);
        }
        clearcache();
        chrome.tabs.sendMessage(tabId, {action: "update"});
        startLoading = false;
    };
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method === "post_request") {
        fetch(request.url, request.body)
            .then((response) => response.json())
            .then((response) => {
                sendResponse({
                    status: 200,
                    result: response,
                });
            })
            .catch((err) => {
                sendResponse({
                    status: 500,
                    error: err,
                });
            });
        return true;
    } else if (request.method === "parallel_post_request") {
        var requests = request.requests;
        var asyncRequests = []
        for (let i = 0; i < requests.length; i++) {
            let url = requests[i].url
            let body = requests[i].body
            const postRequest = fetch(url, body)
                .then((result) => result.json());
            asyncRequests.push(postRequest);
        }
        Promise.all(asyncRequests)
            .then((results) => {
                sendResponse({
                    status: 200,
                    results: results,
                });
            })
            .catch((err) => {
                sendResponse({
                    status: 500,
                    error: err,
                });
            });
        return true;
    } else if (request.method === "close_window") {
        toggleMap[sender.tab.id] = !toggleMap[sender.tab.id];
        checkIcon(sender.tab.id);
    }
});