var cover = document.getElementById("portal-widget-frame-container");
var view = document.createElement("div");
var currentPage = "";
var calculateResultInterval = 5000; // 5 second
var syncDetailResultInterval = 300000; // 5 minutes
var checkPageInterval = 2000; //2 second
var cachedProvider = "";
var cachedRegion = "";
var cachedMaster = {};
var cachedWorker = {};
var AWS_volume_type = 'General Purpose';
var GCP_volume_type='CP-COMPUTEENGINE-STORAGE-PD-CAPACITY';
var Azure_volume_type='standardhdd-s6';
var set_days = 7;
var Isloading = true;
var IsPin = false;
var IsSetting = false;
var selectProvider="";
var cacheCpuPredict = [];
var cacheMemPredict = [];
var cacheCpuHistory = [];
var cacheMemHistory = [];
var cacheData = [];
var cacheAPI='';
var default_username = "fedemeter";
var default_password = "$6$pOwGiawPSjz7qLaN$fnMXEhwzWnUw.bOKohdAhB5K5iCCOJJaZXxQkhzH4URsHP8qLTT4QeBPUKjlOAeAHbKsqlf.fyuL2pNRmR6oQD1";
var token;
token = default_username+":"+default_password;
token = "Basic " + btoa(token);
//console.log(token);

// Color Code
colorBlack = "#000000";
noticeTextColor = "#20B2AA";
noticeMessageLowestColor = "#3FB724";
noticeMessageRecommendationColor = "#0000FF";
noticeMessageErrorColor = "#F50202";

const providerMapping = {
    "aws": "AWS",
    "azure": "Azure",
    "gcp": "GCP",
};

const rootUri = 'nks.netapp.io';
const viewId = 'fedemeter_chrome_extension_view';
//const api_base = 'http://35.197.28.123:31000/fedemeter-api/v1'; //api for the "new" page
const api_base = 'http://54.189.87.139:31000/fedemeter-api/v1'; //api for the "new" page
view.id = viewId;

const checkAndLaunchUrl = (page, content) => {
    currentPage = page;
    if (page === "new") {
        // new page
        injectNewPage(content);
    } else if (page === "choose-provider") {
        // choose provider page
        //injectChooseProviderPage(content);
    } else if (page === "detail") {
        // detail page
        injectDetailPage(content);
        renderDetailPage(content);
    }
};

const toFixed2 = (x) => {
    return Number.parseFloat(x).toFixed(2);
};

const dragElement = (elmnt) => {
    var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    if (document.getElementById(elmnt.id + "header")) {
        // if present, the header is where you move the DIV from:
        document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
    } else {
        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        //e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
        elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

dragElement(view);

const injectNewPage = (content) => {
    console.log("Inject new page");
    //var cover = document.getElementsByClassName("domain-netapp");

    var new_page = document.createElement("div");
    new_page.id = "fedemeter_new_page";
    new_page_html = '<div style="width: 500px; height: 16px;">\
      <div style="float:left" id="sync-button"></div>\
      <div style="display: inline-block; width: 461px; height: 100%; cursor: move;"></div>\
      <div style="float:right" id="close-window"></div></div>\
      <div class="wrapper">\
        <div class="part">\
          <h2 class="title">Current</h2>\
          <div>\
            <span class="plan">Plan: </span>\
            <div class="cost-master-plan">Master\
              <span class="tooltip">\
                <div class="cost-master-block">\
                  <b>Region: </b><span id="cost-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="cost-master-nodes">No Data</span><br />\
                  <b>Size: </b><span id="cost-master-size">No Data</span><br />\
                  <b>Disk: </b><span id="cost-master-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="cost-worker-plan">Worker\
              <span class="tooltip">\
                <div class="cost-worker-block">\
                  <b>Region: </b><span id="cost-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="cost-worker-nodes">No Data</span><br />\
                  <b>Size: </b><span id="cost-worker-size">No Data</span><br />\
                  <b>Disk: </b><span id="cost-worker-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price"><span id="cost-per-month">--</span><b>/month</b></p>\
          <span class="provider"> <b>Provider: </b> <span id="cost-provider"></span><br /></span>\
        </div>\
        <div class="part">\
          <h2 class="title">Our Recommendation</h2>\
          <div>\
            <span class="plan">Plan: </span>\
            <div class="rec-master-plan">Master\
              <span class="tooltip">\
                <div class="rec-master-block">\
                  <b>Region: </b><span id="rec-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="rec-master-nodes">No Data</span><br />\
                  <b>Size: </b><span id="rec-master-size">No Data</span><br />\
                  <b>Disk: </b><span id="rec-master-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="rec-worker-plan">Worker\
              <span class="tooltip">\
                <div class="rec-worker-block">\
                  <b>Region: </b><span id="rec-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="rec-worker-nodes">No Data</span><br />\
                  <b>Size: </b><span id="rec-worker-size">No Data</span><br />\
                  <b>Disk: </b><span id="rec-worker-disk">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price"><span id="recommendation">--</span><b>/month</b></p>\
          <span class="provider"><b>Provider: <select id="sort-provider"></select> <div id="pin" style="display: inline-block;"><div id="new-unpin"></div></div></b>\
        </div>\
      </div>\
      <div style="">\
        <div id="collapse-notice"></div>\
        <div id="expand-notice"></div>\
        <div id="notice_part" style="display:none">\
          <div class="notice">\
            <span id="notice_message"><b>No Data</b></span>\
          </div>\
          <div class="wrapper">\
            <div class="part">\
              <div class="notice-title"><b>Master</b></div>\
              <div class="notice-master">\
                <b>Region: </b><br /><span id="notice-master-region">No Data</span><br />\
                <b>Node(s): </b><br /><span id="notice-master-nodes">No Data</span><br />\
                <b>Size: </b><br /><span id="notice-master-size">No Data</span><br />\
                <b>Disk: </b><br /><span id="notice-master-disk">No Data</span><br />\
              </div>\
            </div>\
            <div class="part">\
              <div class="notice-title"><b>Worker</b></div>\
              <div class="notice-worker">\
                <b>Region: </b><br /><span id="notice-worker-region">No Data</span><br />\
                <b>Node(s): </b><br /><span id="notice-worker-nodes">No Data</span><br />\
                <b>Size: </b><br /><span id="notice-worker-size">No Data</span><br />\
                <b>Disk: </b><br /><span id="notice-worker-disk">No Data</span><br />\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>';
    new_page.innerHTML = new_page_html;
    view.setAttribute('style', `background-color: #FAFAFA; position: fixed; top: 10px; right: 10px; width: 500px; border: 1px gray solid; z-index: 999;`);
    view.appendChild(new_page);
    cover.appendChild(view);

    document.getElementById('close-window').addEventListener('click', () => {
        chrome.runtime.sendMessage({"method": "close_window"});
    });

    renderNewPage(content, true);
    $("#sync-button").bind('click', syncPage);
    document.getElementById('collapse-notice').addEventListener('click', () => {
        obj = document.getElementById('notice_part');
        collapseImg = document.getElementById('collapse-notice');
        expandImg = document.getElementById('expand-notice');
        if (!obj) {
            return true;
        }
        obj.style.display = "none";
        collapseImg.style.display = "none";
        expandImg.style.display = "block";
        return true;
    });
    pin = document.getElementById('pin');
    pin.addEventListener('click',() => {
        if(IsPin){
            $('#pin').html('<div id="new-unpin"></div>');
            IsPin=!IsPin;
        } else if(!IsPin){
            $('#pin').html('<div id="new-pin"></div>');
            IsPin=!IsPin;
        }
    });

    document.getElementById('expand-notice').addEventListener('click', () => {
        obj = document.getElementById('notice_part');
        collapseImg = document.getElementById('collapse-notice');
        expandImg = document.getElementById('expand-notice');

        if (!obj) {
            return true;
        }
        obj.style.display = "block";
        collapseImg.style.display = "block";
        expandImg.style.display = "none";
        return true;
    });
};

const injectChooseProviderPage = () => {
    console.log("Inject choose provider page");
    //var cover = document.getElementsByClassName("domain-netapp");

    var choose_provider_page = document.createElement("div");
    choose_provider_page.id = "fedemeter_choose_provider_page";
    choose_provider_page_html = '<div class="info-wrapper">\
      <div class="main-page-add" id="azure">\
        <h2 class="provider">Azure</h2>\
        <div class="main-page-add-body">\
          <p>\
            <b class="title">europe-west: </b>\
            <span class="description">Most choices of VM types</span>\
          </p>\
          <p>\
            <b class="title">usgov-iowa: </b>\
            <span class="description">Lowest average prices of VMs</span>\
          </p>\
          <p>\
            <b class="title">usgov-iowa: </b>\
            <span class="description">Better prices for compute-intensive workloads</span>\
          </p>\
          <p>\
            <b class="title">usgov-iowa: </b>\
            <span class="description">Better prices fo GPU-enabled computing</span>\
          </p>\
        </div>\
      </div>\
      <div class="main-page-add" id="aws">\
        <h2 class="provider">AWS</h2>\
        <div class="main-page-add-body">\
          <p>\
            <b class="title">Asia Pacific (Osaka-Local): </b>\
            <span class="description">Better prices for general purpose workloads</span>\
          </p>\
          <p>\
            <b class="title">AWS GovCloud (US): </b>\
            <span class="description">Better prices for storage optimized workloads</span>\
          </p>\
        </div>\
      </div>\
      <div class="main-page-add" id="gcp">\
        <h2 class="provider">GCP</h2>\
        <div class="main-page-add-body">\
          <p>\
            <b class="title">southamerica-east1: </b>\
            <span class="description">Better prices for memory optimized workloads</span>\
          </p>\
        </div>\
      </div>\
    </div>';
    choose_provider_page.innerHTML = choose_provider_page_html;
    view.setAttribute('style', `position: fixed; top: 10px; right: 10px; border: 1px gray solid; z-index: 60;`);
    view.appendChild(choose_provider_page);
    cover.appendChild(view);
};


const injectDetailPage = (content) => {
    console.log("Inject detail page");

    //var cover = document.getElementsByClassName("domain-netapp");
    var detail_page = document.createElement("div");
    detail_page.id = "fedemeter_detail_page";
    detail_page_html = '<div style="float:left" id="sync-button"></div>\
        <div>\
        <select style="float:left;font-family: Roboto,Helvetica Neue,sans-serif;margin-left:5px;display:none;" id="setting-button">\
        <option value="" disabled selected hidden></option>\
        <option value="workload" style="font-size: 14px;">Workload Setting</option>\
        </select>\
        </div>\
              <span class="tooltip">\
                <div class="currently-cost-master-block">\
                </div>\
                <div style="float:right" id="close-window"></div>\
                <div id="dropdown" style="display:none;">\
                </div>\
              </span>\
      </div>\
       <div style="display: inline-block; width: 600px; height: 200%; cursor: move;"></div>\
      </div>\
      <div><img id="loading"></div>\
      <div id="chartDiv">\
      <from id="set-workload"></from>\
          <div id="cpu-and-memory-chart" style="width:600px"></div>\
          <div id="modified-workload" style="width:600px"></div>\
          <div id="num-of-vms-chart" style="width:600px"></div>\
        </div>\
      <div id="collapse-chart"></div>\
      <div id="expand-chart"></div>\
      <div id="monthly-cost-chart" style="width:600px"></div>\
          ';

    detail_page.innerHTML = detail_page_html;
    view.setAttribute('style', `background-color: white; maxHeight: 600px; width: 600px; position: fixed; top: 10px; right: 10px; border: 1px gray solid; z-index: 60`);
    view.appendChild(detail_page);
    cover.appendChild(view);
    dropdown();
    loadingImg = document.getElementById('loading');
    loadingImg.src = chrome.extension.getURL("images/loading2.gif");

    document.getElementById('close-window').addEventListener('click', () => {
        chrome.runtime.sendMessage({"method": "close_window"});
    });
    document.getElementById('setting-button').addEventListener('change',() =>{
        var setting = document.getElementById('setting-button')
        console.log("setting event")
        if (setting.value === "workload" && !Isloading){
            document.getElementById('set-workload').style.display = 'unset';
            document.getElementById('modified-workload').style.display = 'unset';
            document.getElementById('num-of-vms-chart').style.display='none';
            document.getElementById('monthly-cost-chart').style.display='none';
            document.getElementById('collapse-chart').style.display='none';
            IsSetting = true;
            setWorkload();
        } else if (setting.value === "workload" && Isloading){
            setting.value="loading";
            console.log("loading");
        }
    });
    document.getElementById('collapse-chart').addEventListener('click', () => {
        obj = document.getElementById('chartDiv');
        collapseImg = document.getElementById('collapse-chart');
        expandImg = document.getElementById('expand-chart');

        if (!obj) {
            return true;
        }
        obj.style.display = "none";
        collapseImg.style.display = "none";
        expandImg.style.display = "block";
        return true;
    });

    document.getElementById('expand-chart').addEventListener('click', () => {
        obj = document.getElementById('chartDiv');
        collapseImg = document.getElementById('collapse-chart');
        expandImg = document.getElementById('expand-chart');

        if (!obj) {
            return true;
        }
        obj.style.display = "block";
        collapseImg.style.display = "block";
        expandImg.style.display = "none";
        return true;
    });
};

const setWorkload = () =>{
    $('#set-workload').html('<input type="radio" name="workload" value="cpu" checked="true"> CPU Workload\
    <input type="radio" name="workload" value="mem">Memory Workload\
    <select style="float:right;" id="workload-select">\
    <option value="month">Month</option>\
    <option value="year">Year</option>\
    </select>\
    ');

    var reloadCpu=cacheCpuPredict;
    var reloadMem = cacheMemPredict;
    var IsCpu=true;
    var tempCpuPredictLoad=[];
    var tempMemPredictLoad=[];
    var CpuWorkloadColumn = new Array();
    var MemWorkloadColumn = new Array();
    var CpuWorkloadColumnyear = new Array();
    var MemWorkloadColumnyear = new Array();
    var workloadevent = document.getElementById('workload-select');
    var loadhtml="";
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    };
    const method = 'PUT';
    const predictedUtilization = JSON.stringify({
        resource: [
            Object.assign({}, cacheData, {
                category: 'predicted',
                type: 'workload',
            })
        ],
    });
    var request=[];
    var timestamp = Math.floor(Date.now()/1000);
    var predict_tsfrom =timestamp;
    var predict_tsto =timestamp + 60*60*24*30;
    var granularity = 86400;
    var fill_days = 30;
    var setting_days = 30;
    request.push({
    url: `${cacheAPI}/resources/predictions/workloads?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
        body: Object.assign({}, {
            headers,
            method,
            body: predictedUtilization
        })
    });
    var predictionsWorkload = {};
    chrome.runtime.sendMessage({
        "method": "parallel_post_request",
        "requests": request,
    }, (response) => {
        if (response["status"] != 200) {
            console.log(response["error"]);
            console.log("Error occurred during setDetailView");
            return
        }
        var results = response["results"];
        console.log("Query Setting Response from API successfully");
        predictionsWorkload = results[0];
        console.log("Predicted Workload");
        console.log(predictionsWorkload);
        parsePredictWorkload(predictionsWorkload);
        setSettingChart(setting_days);
        setLoadCpuMemChart(cacheCpuPredict,[],[]);
    });

    document.getElementById('workload-select').addEventListener('change',()=>{
        var request=[];
        var timestamp = Math.floor(Date.now()/1000);
        var predict_tsfrom =timestamp;
        var setting_days = 30;
        if (document.getElementById('workload-select').value==="month"){
            var predict_tsto =timestamp + 60*60*24*30;
            var granularity = 86400;
            var fill_days = 30;
            setting_days = 30;
            request.push({
            url: `${cacheAPI}/resources/predictions/workloads?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
                body: Object.assign({}, {
                    headers,
                    method,
                    body: predictedUtilization
                })
            });
        } else if (document.getElementById('workload-select').value==="year") {
            var predict_tsto =timestamp + 60*60*24*365;
            var granularity = 86400*30;
            var fill_days = 365;
            setting_days = 365;

            request.push({
            url: `${cacheAPI}/resources/predictions/workloads?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
                body: Object.assign({}, {
                    headers,
                    method,
                    body: predictedUtilization
                })
            });
        }

        var predictionsWorkload = {};
        chrome.runtime.sendMessage({
            "method": "parallel_post_request",
            "requests": request,
        }, (response) => {
            if (response["status"] != 200) {
                console.log(response["error"]);
                console.log("Error occurred during setDetailView");
                return
            }
            var results = response["results"];
            console.log("Query Setting Response from API successfully");
            predictionsWorkload = results[0];
            console.log("Predicted Workload");
            console.log(predictionsWorkload);
            parsePredictWorkload(predictionsWorkload);
            if(IsCpu && workloadevent.value==="month"){
                setLoadCpuMemChart(cacheCpuPredict,[],CpuWorkloadColumn);
            } else if (!IsCpu && workloadevent.value==="month"){
                setLoadCpuMemChart([],cacheMemPredict,MemWorkloadColumn);
            } else if (IsCpu && workloadevent.value==="year"){
                setLoadCpuMemChart(cacheCpuPredict,[],CpuWorkloadColumnyear);
            } else if (!IsCpu && workloadevent.value==="year"){
                setLoadCpuMemChart([],cacheMemPredict,MemWorkloadColumnyear);
            }
            setSettingChart(setting_days);

        });
    });

    const setSettingChart=(setting_days)=>{
            loadhtml="";
            if (setting_days===30){
                for (var j=0; j < cacheCpuPredict.length;j++){
                    tempCpuPredictLoad[j]=Array.from(cacheCpuPredict[j]);
                    tempMemPredictLoad[j]=Array.from(cacheMemPredict[j]);
                    if (j===0) {
                        loadhtml=loadhtml+ '<div class="load" value="'+j+'" style="margin-left: 65px" id="load-button"></div>';
                    } else {
                        loadhtml=loadhtml+ '<div class="load" value="'+j+'" style="margin-left: 7.6px" id="load-button"></div>';
                    }
                }
            } else if (setting_days===365){
                for (var j=0; j < cacheCpuPredict.length;j++){
                    tempCpuPredictLoad[j]=Array.from(cacheCpuPredict[j]);
                    tempMemPredictLoad[j]=Array.from(cacheMemPredict[j]);
                    if (j===0) {
                        loadhtml=loadhtml+ '<div class="load" value="'+j+'" style="margin-left: 80px" id="load-button"></div>';
                    } else {
                        loadhtml=loadhtml+ '<div class="load" value="'+j+'" style="margin-left: 30px" id="load-button"></div>';
                    }
                }
            }
            $('#modified-workload').html(loadhtml+'</br><button style="float:right;" id=close>Close</button>\
                <button style="float:right;" id=reset>Reset</button>\
                <button style="float:right;" id=apply>Apply</button>');
            var btnOnload=document.getElementsByClassName("load");
            var btnOnloadArr = Array.prototype.slice.call(btnOnload);
            btnOnloadArr.forEach(function(button, index){
                button.addEventListener('click', function(){
                    if(IsCpu){
                        var setworkloading = prompt("Please enter CPU workload " ,tempCpuPredictLoad[index][1].toFixed(2));
                        if ( setworkloading !== null){
                            if (workloadevent.value==="month"){
                                CpuWorkloadColumn = checkDeduplicateAndSignValue(CpuWorkloadColumn,tempCpuPredictLoad[index],setworkloading);
                                setLoadCpuMemChart(cacheCpuPredict,empty,CpuWorkloadColumn);
                            } else if (workloadevent.value==="year"){
                                CpuWorkloadColumnyear = checkDeduplicateAndSignValue(CpuWorkloadColumnyear,tempCpuPredictLoad[index],setworkloading);
                                setLoadCpuMemChart(cacheCpuPredict,empty,CpuWorkloadColumnyear);
                            }
                        }
                    } else {
                        var setworkloading = prompt("Please enter Memory workload ", tempMemPredictLoad[index][1].toFixed(2));
                        if ( setworkloading !== null){
                            if(workloadevent.value==="month"){
                                MemWorkloadColumn = checkDeduplicateAndSignValue(MemWorkloadColumn,tempMemPredictLoad[index],setworkloading);
                                setLoadCpuMemChart(empty,cacheMemPredict,MemWorkloadColumn);
                            } else if (workloadevent.value==="year"){
                                MemWorkloadColumnyear = checkDeduplicateAndSignValue(MemWorkloadColumnyear,tempMemPredictLoad[index],setworkloading);
                                setLoadCpuMemChart(empty,cacheMemPredict,MemWorkloadColumnyear);
                            }
                        }
                    }
                });
            });
            close = document.getElementById('close');
            close.addEventListener('click',() => {
            document.getElementById('setting-button').value = 'none';
            document.getElementById('set-workload').style.display = 'none';
            document.getElementById('modified-workload').style.display = 'none';
            document.getElementById('num-of-vms-chart').style.display='unset';
            document.getElementById('monthly-cost-chart').style.display='unset';
            document.getElementById('collapse-chart').style.display='unset';
            IsSetting=false;
            setCpuMemChart(cacheCpuHistory,cacheMemHistory,reloadCpu,reloadMem);
        });
        document.getElementById('reset').addEventListener('click',()=>{
            CpuWorkloadColumn = [];
            MemWorkloadColumn = [];
            CpuWorkloadColumnyear = [];
            MemWorkloadColumnyear = [];
            if(IsCpu){
                setLoadCpuMemChart(cacheCpuPredict,[],CpuWorkloadColumn);
            } else {
                setLoadCpuMemChart([],cacheMemPredict,CpuWorkloadColumn);
            }
        });
    }
    setLoadCpuMemChart([],[],[]);
    $('#modified-workload').html(loadhtml+'</br><button style="float:right;" id=close>Close</button>\
        <button style="float:right;" id=reset>Reset</button>\
        <button style="float:right;" id=apply>Apply</button>');
    const empty = [];

    workload = document.getElementsByName('workload');
    workload[0].addEventListener('click',()=>{
        IsCpu=true;
        if(workloadevent.value==="month"){
            setLoadCpuMemChart(cacheCpuPredict,empty,CpuWorkloadColumn);
        } else if (workloadevent.value==="year"){
            setLoadCpuMemChart(cacheCpuPredict,empty,CpuWorkloadColumnyear);
        }

    });
    workload[1].addEventListener('click',()=>{
        IsCpu=false;
        if(workloadevent.value==="month"){
            setLoadCpuMemChart(empty,cacheMemPredict,MemWorkloadColumn);
        }else if (workloadevent.value==="year"){
            setLoadCpuMemChart(empty,cacheMemPredict,MemWorkloadColumnyear);
        }
    });
}

const parsePredictWorkload = (predictionsWorkload) =>{
    totalResource = {};
    const clusterName = cacheData.clustername;
    const predictedData = predictionsWorkload.resource[clusterName];
    const cpuPredict = {};
    const memPredict = {};
    for (var vendor in predictedData) {
        cpuPredict[vendor] = [];
        memPredict[vendor] = [];
        totalResource[vendor] = {};
        totalCpu = 0.0;
        totalMemory = 0.0;
        for (let i = 0; i < predictedData[vendor].length; i++) {
            const predictionDataTarget = predictedData[vendor][i];
            const predictionData = predictionDataTarget[Object.keys(predictionDataTarget)[0]].utilization;
            totalCpu += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["cpu_cores"];
            totalMemory += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["memory_total"];
            predictionData.forEach(({
                cpu,
                memory,
                timestamp
            }) => {
                if (!(timestamp in totalResource[vendor])) {
                    totalResource[vendor][timestamp] = {};
                    totalResource[vendor][timestamp]["cpu"] = 0.0;
                    totalResource[vendor][timestamp]["memory"] = 0.0;
                }
                totalResource[vendor][timestamp]["cpu"] += cpu;
                totalResource[vendor][timestamp]["memory"] += memory;
            });
        }

        Object.keys(totalResource[vendor]).sort().forEach(function(key) {
            const time = key * 1000;
            var Cpu = totalResource[vendor][key]["cpu"] / totalCpu
            var Memory = totalResource[vendor][key]["memory"] / totalMemory
            cpuPredict[vendor].push([time, Cpu * 100]);
            memPredict[vendor].push([time, Memory * 100]);
        });
    }
    cacheCpuPredict=cpuPredict[cachedProvider];
    cacheMemPredict=memPredict[cachedProvider];
}

const checkDeduplicateAndSignValue = (checkColumn, value, signValue)=>{
    for (var index in checkColumn){
        if(checkColumn[index][0] == value[0]){
            checkColumn[index][1] = parseFloat(signValue);
            return checkColumn;
        }
    }
    checkColumn[checkColumn.length]=value;
    checkColumn[checkColumn.length-1][1]=parseFloat(signValue);
    return checkColumn;
}


const setLoadCpuMemChart = (cpuPredict, memPredict, workloadColumn) => {
    var min;
    var max;
    if(cpuPredict.length===0){
        cpudiaplay = false;
    } else {
        min = cpuPredict[0][0];
        max = cpuPredict[cpuPredict.length-1][0];
        cpudiaplay = true;
    }
    if(memPredict.length===0){
        memdiaplay = false;
    } else {
        min = memPredict[0][0];
        max = memPredict[memPredict.length-1][0];
        memdiaplay = true;
    }
    plotLineId = 'clusterCapacityLine'
    plotLineOptions = {
        id: plotLineId,
        value: 100,
        width: 2,
        dashStyle: 'ShortDash',
        color: '#5cc770',
        label: {
            text: 'Cluster Capacity',
            y: 20
        },
        zIndex: 5,
    };
    $('#cpu-and-memory-chart').highcharts({
        chart: {
            height: 187,
            width: 600,
            plotBorderWidth: 1,
            marginRight: 10,
        },
        title: {
            margin: 0,
            text: 'Resource Utilization for Managed Pods',
        },
        xAxis: {
            type: 'datetime',
            tickPixelInterval: 80,
            min,
            max,
        },
        yAxis: [{
            labels: {
                useHTML:true,
                style:{
                    width:'40px',
                    whiteSpace:'normal'
                },
                formatter: function () {
                    return '<div align="right" style="word-wrap: break-word;word-break: break-all;width:40px">' + this.value + ' %</div>';
                }
            },
            title: {
                text: null,
            },
            maxPadding: 0,
            plotLines: [],
            tickAmount: 6,
        }],
        tooltip: {
            shared: true,
            crosshairs: true,
            useHTML: true,
            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:.2f} %</b><br/>',
            headerFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                '<b>{point.point.symbolName}</b><br>',
        },
        legend: {
            margin: 2,
            align: 'left',
            verticalAlign: 'top',
            borderWidth: 0,
            itemDistance: 10,
        },
        exporting: {
            enabled: false
        },
        series: [
            {
                color: '#e22e5d',
                type: 'spline',
                name: 'CPU Predicted',
                tooltip: {
                    valueSuffix: ' %'
                },
                dashStyle: 'ShortDot',
                data: cpuPredict,
                visible: cpudiaplay,
                marker: {
                    symbol: "circle"
                }
            },
            {
                color: '#fc7095',
                type: 'spline',
                name: 'Memory Predicted',
                tooltip: {
                    valueSuffix: ' %'
                },
                dashStyle: 'ShortDot',
                data: memPredict,
                visible: memdiaplay,
                marker: {
                    symbol: "diamond"
                }
            },
            {
                name: 'Workload',
                color: '#d3572d',
                data: workloadColumn,
                type:'column',
                stack: 'workload',
                stacking: 'normal',
                pointWidth: 5,
            },
        ],
    }
    );
};

const syncPage = () => {
    const {
        page,
        content,
    } = getPathName();

    if (page === "detail") {
        obj = document.getElementById('chartDiv');
        collapseImg = document.getElementById('collapse-chart');
        expandImg = document.getElementById('expand-chart');
        obj.style.display = "block";
        collapseImg.style.display = "block";
        expandImg.style.display = "none";
        renderDetailPage(content, true);
    } else if (page === "new") {
        const {
            provider,
            region,
            master,
            worker,
        } = content;
        cachedProvider = provider;
        cachedRegion = region;
        cachedMaster = master;
        cachedWorker = worker;
        renderNewPage(content, false);
    }
};

const sortrecommenders = (recommenders) => {
    var rec= []
     rec["aws"] = '<option value="aws">AWS</option>';
     rec["gcp"] = '<option value="gcp">GCP</option>';
     rec["azure"] = '<option value="azure">Azure</option>';
    var tempcost=[];
    var cost=Array(3);
    var counter=0;
    for(var recProvider in recommenders){
        const [master, worker] = recommenders[recProvider];
        if (master["status"]==="OK" && worker["status"]==="OK"){
            tempcost[master["totalcost"] + worker["totalcost"]] = recProvider;
            cost[counter] = master["totalcost"] + worker["totalcost"]
            counter++;
        }
    }
    cost=selectionSort(cost);
    const length = cost.length;
    var sort = "";
    for  (let i = 0; i < length; i++){
       sort=sort+rec[tempcost[cost[i]]];
    }
    return sort;
}

const selectionSort = (arr) => {
    const length = arr.length;

    for (let i = 0; i < length; i++) {

      let min = arr[i];
      let minIndex = i;

      for (let j = i; j < length; j++) {
        if (arr[j] < min) {
          min = arr[j];
          minIndex = j;
        }
      }
      [arr[minIndex], arr[i]] = [arr[i], arr[minIndex]];
    }
    return arr;
}

const renderNewPage = (content, expand_page=false) => {

    var errorbit = false;
    var errordescription = "";
    // render data
    const {
        provider,
        region,
        master,
        worker,
    } = content;

    let master_content = {
        region,
        instances: {
            instancetype: master.disk,
            operatingsystem: master.os_type,
            preinstalledsw: "NA",
            instancenum: master.count,
            period: "1",
            unit: "month"
        },
        storage: [{
            volumetype: master.volume_type,
            storagesize: master.size,
            storagenum: master.count,
            period: "1",
            unit: "month"
        }]
    }
    if (master.gpunum != "0") {
        master_content = Object.assign(master_content, {
            gpu: {
                gpuinstance: master.gpuinstance,
                gpunum: master.gpunum,
                period: "1",
                unit: "month",
            },
        })
    }

    let worker_content = {
        region,
        instances: {
            instancetype: worker.disk,
            operatingsystem: worker.os_type,
            preinstalledsw: "NA",
            instancenum: worker.count,
            period: "1",
            unit: "month"
        },
        storage: [{
            volumetype: worker.volume_type,
            storagesize: worker.size,
            storagenum: worker.count,
            period: "1",
            unit: "month"
        }],
    };
    if (worker.gpunum != "0") {
        worker_content = Object.assign(worker_content, {
            gpu: {
                gpuinstance: worker.gpuinstance,
                gpunum: worker.gpunum,
                period: "1",
                unit: "month",
            },
        })
    }

    const calculator_data = {
        [provider]: [
            master_content,
            worker_content,
        ],
    };

    let rec_master_content = {
        region,
        instances: {
            instancetype: master.disk,
            nodetype: "master",
            operatingsystem: master.os_type,
            preinstalledsw: "NA",
            instancenum: master.count,
            period: "1",
            unit: "month"
        },
        storage: [{
            volumetype: master.volume_type,
            storagesize: master.size,
            storagenum: master.count,
            period: "1",
            unit: "month"
        }]
    }
    if (master.gpunum != "0") {
        master_content = Object.assign(rec_master_content, {
            gpu: {
                gpuinstance: master.gpuinstance,
                gpunum: master.gpunum,
                period: "1",
                unit: "month",
            },
        })
    }

    let rec_worker_content = {
        region,
        instances: {
            instancetype: worker.disk,
            nodetype: "worker",
            operatingsystem: worker.os_type,
            preinstalledsw: "NA",
            instancenum: worker.count,
            period: "1",
            unit: "month"
        },
        storage: [{
            volumetype: worker.volume_type,
            storagesize: worker.size,
            storagenum: worker.count,
            period: "1",
            unit: "month"
        }],
    }
    if (worker.gpunum != "0") {
        worker_content = Object.assign(rec_worker_content, {
            gpu: {
                gpuinstance: worker.gpuinstance,
                gpunum: worker.gpunum,
                period: "1",
                unit: "month",
            },
        })
    }

    const recommender_data = {
        acceptance: [{
            "provider": "*"
        }, ],
        configuration: {
            [provider]: [
                rec_master_content,
                rec_worker_content,
            ],
        }
    };

    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
        //'Authorization':token
    };
    const method = 'PUT';

    const calculatorBody = JSON.stringify({
        calculator: [calculator_data],
    });

    const recommendationBody = JSON.stringify({
        recommender: [recommender_data],
    });

    let costTotal = 0;
    let recTotal = 0;
    var requestsList = []

    requestsList.push({
        url: `${api_base}/calculators/`,
        body: Object.assign({}, {
            headers,
            method,
            body: calculatorBody
        })
    });
    requestsList.push({
        url: `${api_base}/recommendations/jri/`,
        body: Object.assign({}, {
            headers,
            method,
            body: recommendationBody
        })
    });

    chrome.runtime.sendMessage({
        "method": "parallel_post_request",
        "requests": requestsList,
    }, (response) => {
        if (response["status"] != 200) {
            console.log("Access error");
            console.log(response);
            return ;
        }

        var results = response["results"];
        console.log("Query Response from API successfully");
        calculatorResult = results[0];
        recommendationsResult = results[1];
        console.log("Calculators");
        console.log(calculatorResult);
        console.log("Recommendations JRI");
        console.log(recommendationsResult);
        var costTotal=0;

        // Calculators part
        const {
            calculator = []
        } = calculatorResult;

        if (calculator.length) {
            const [master, worker] = calculator[0][provider];
            if(master["status"] === "OK" ){
                const {
                    instances: {
                        instancenum: masterNodes,
                        displayname: masterType,
                    },
                    region: masterRegion,
                    storage: [{
                        storagesize: masterSize,
                    }],
                    totalcost: masterTotal,
                    status: masterStatus,
                } = master;

                costTotal=masterTotal;
                $('#cost-master-region').text(masterRegion);
                $('#cost-master-nodes').text(masterNodes);
                $('#cost-master-size').text(masterType);
                $('#cost-master-disk').text(`${masterSize}GB`);
            }else{
                errorbit = true;
                errordescription = calculator[0][provider][0]["status"];
                console.log(errordescription);
            }
            if (worker["status"] === "OK"){
                const {
                    instances: {
                        instancenum: workerNodes,
                        displayname: workerType,
                    },
                    region: workerRegion,
                    storage: [{
                        storagesize: workerSize,
                    }],
                    totalcost: workerTotal,
                    status:workerStatus,
                } = worker;
                var providersUpper;
                if(provider==="azure"){
                    providersUpper="Azure"
                } else {
                    providersUpper = provider.toUpperCase();
                }
                $('#cost-provider').text(providersUpper);
                $('#cost-worker-region').text(workerRegion);
                $('#cost-worker-nodes').text(workerNodes);
                $('#cost-worker-size').text(workerType);
                $('#cost-worker-disk').text(`${workerSize}GB`);
                costTotal = costTotal + workerTotal || NaN;
                $('#cost-per-month').text(`\$${toFixed2(costTotal)}`);
            }else{
                errorbit = true;
                errordescription = calculator[0][provider][1]["status"];
                console.log(errordescription);
            }
        }

        // Recommendations part
        const {
            recommender = []
        } = recommendationsResult;

        const recommenders = Object.assign(...recommender);
        var sort=sortrecommenders(recommenders);
        var cheapestcost = 999999999999;
        var cheapest_provider = "";
        errorbit = false;

        for(var recProvider in recommenders){
            const [master, worker] = recommenders[recProvider];
            if (master["status"]==="OK" && worker["status"]==="OK"){
                tempcost = master["totalcost"] + worker["totalcost"];
                if (tempcost < cheapestcost){
                    cheapest_provider = recProvider;
                    cheapestcost = tempcost;
                    if(selectProvider===""){
                        selectProvider = cheapest_provider;
                    }
                }
            }
        }
        if (expand_page) {
            $('#notice_part').css({display: "block"});
        }

        if(recommender.length&&!IsPin){
            $('#sort-provider').html(sort);
            recProviderInNewPage(calculator, recommenders, provider, cheapest_provider, cheapest_provider, costTotal, errorbit, errordescription)
        } else if (recommender.length&&IsPin){
            recProviderInNewPage(calculator, recommenders, provider, selectProvider, cheapest_provider, costTotal, errorbit, errordescription);
        }
        const active = document.getElementById('sort-provider');
        active.addEventListener("change", ()=>{
            selectProvider = active.value;
            recProviderInNewPage(calculator, recommenders, provider, active.value, cheapest_provider, costTotal, errorbit, errordescription);
        });
    });
};
const recProviderInNewPage = (calculator, recommenders, provider, current_provider, cheapest_provider, costTotal, errorbit, errordescription)=>{

        if (current_provider===""){
            // Use provider instead
            const [master, worker] = recommenders[provider];
            errorbit = true;
            if(master["status"]!=="OK"){
                errordescription = master["status"];
            } else {
                errordescription = worker["status"];
            }
            console.log(errordescription);
        }
        if(!errorbit){
            console.log(recommenders);
            console.log(current_provider);
            const [master, worker] = recommenders[current_provider];
            const {
                instances: {
                    instancenum: masterNodes,
                    displayname: masterType,
                },
                region: masterRegion,
                storage: [{
                    storagesize: masterSize,
                }],
                totalcost: masterTotal,
                status:recMasterStatus,
            } = master;
            const {
                instances: {
                    instancenum: workerNodes,
                    displayname: workerType,
                },
                region: workerRegion,
                storage: [{
                    storagesize: workerSize,
                }],
                totalcost: workerTotal,
                status:recWorkerStatus,
            } = worker;
            $('#rec-master-region').text(masterRegion);
            $('#rec-master-nodes').text(masterNodes);
            $('#rec-master-size').text(masterType);
            $('#rec-master-disk').text(`${masterSize}GB`);

            $('#notice-master-region').text(masterRegion);
            $('#notice-master-nodes').text(masterNodes);
            $('#notice-master-size').text(masterType);
            $('#notice-master-disk').text(`${masterSize}GB`);

            $('#rec-worker-region').text(workerRegion);
            $('#rec-worker-nodes').text(workerNodes);
            $('#rec-worker-size').text(workerType);
            $('#rec-worker-disk').text(`${workerSize}GB`);

            $('#notice-worker-region').text(workerRegion);
            $('#notice-worker-nodes').text(workerNodes);
            $('#notice-worker-size').text(workerType);
            $('#notice-worker-disk').text(`${workerSize}GB`);
            //$('#rec-provider').text(cheapest_provider);
            recTotal = masterTotal + workerTotal || NaN;
            $('#recommendation').text(`\$${toFixed2(recTotal)}`);

            // Highlight notice part
            const [cal_master, cal_worker] = calculator[0][provider];
            if(cal_master["status"] === "OK" && cal_worker["status"] === "OK"){
                const {
                    instances: {
                        instancenum: cal_masterNodes,
                        displayname: cal_masterType,
                    },
                    region: cal_masterRegion,
                    storage: [{
                        storagesize: cal_masterSize,
                    }],
                    totalcost: cal_masterTotal,
                    status: cal_masterStatus,
                } = cal_master;
                const {
                    instances: {
                        instancenum: cal_workerNodes,
                        displayname: cal_workerType,
                    },
                    region: cal_workerRegion,
                    storage: [{
                        storagesize: cal_workerSize,
                    }],
                    totalcost: cal_workerTotal,
                    status: cal_workerStatus,
                } = cal_worker;
                if (cal_masterRegion !== masterRegion) {
                    console.log("highlight masterRegion");
                    $('#notice-master-region').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-master-region').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_masterNodes !== masterNodes) {
                    console.log("highlight masterNode");
                    $('#notice-master-nodes').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-master-nodes').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_masterType !== masterType) {
                    console.log("highlight masterType");
                    $('#notice-master-size').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-master-size').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_masterSize !== masterSize) {
                    console.log("highlight masterSize");
                    $('#notice-master-disk').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-master-disk').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_workerRegion !== workerRegion) {
                    console.log("highlight workerRegion");
                    $('#notice-worker-region').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-worker-region').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_workerNodes !== workerNodes) {
                    console.log("highlight workerNode");
                    $('#notice-worker-nodes').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-worker-nodes').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_workerType !== workerType) {
                    console.log("highlight workerType");
                    $('#notice-worker-size').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-worker-size').css({"color": colorBlack, "font-weight": "normal"});
                }
                if (cal_workerSize !== workerSize) {
                    console.log("highlight workerSize");
                    $('#notice-worker-disk').css({"color": noticeTextColor, "font-weight": "bold"});
                } else {
                    $('#notice-worker-disk').css({"color": colorBlack, "font-weight": "normal"});
                }
            }

            if(errordescription === ""){
                if (costTotal === recTotal) {
                    if (current_provider === cheapest_provider) {
                        $('#notice_message').css({color: noticeMessageLowestColor});
                        $('#notice_message').text("Your current plan is the lowest price to deploy cluster.");
                    } else {
                        $('#notice_message').css({color: noticeMessageRecommendationColor});
                        $('#notice_message').text(`See our recommendation of ${providerMapping[cheapest_provider]} for the lowest price plan.`);
                    }
                } else if (costTotal > recTotal) {
                    const saveTotal = toFixed2(costTotal) - toFixed2(recTotal);
                    $('#notice_message').css({color: noticeMessageRecommendationColor});
                    $('#notice_message').text(`Apply our recommendation to save \$${toFixed2(saveTotal)}/month.`);
                } else if (costTotal < recTotal) {
                    if (current_provider === cheapest_provider) {
                        $('#notice_message').css({color: noticeMessageLowestColor});
                        $('#notice_message').text("Your current plan is the lowest price to deploy cluster.");
                    } else {
                        $('#notice_message').css({color: noticeMessageRecommendationColor});
                        $('#notice_message').text(`See our recommendation of ${providerMapping[cheapest_provider]} for the lowest price plan.`);
                    }
                }
            } else {
                $('#notice_message').css({color: noticeMessageErrorColor});
                $('#notice_message').text(errordescription);
            }
        } else {
            $('#notice_message').css({color: noticeMessageErrorColor});
            $('#notice_message').text(errordescription);
        }
}

const renderDetailPage = (content, loading=false) => {
    var syncingPage;
    Isloading = true;

    if (loading) {
        syncingPage = document.createElement("img");
        syncingPage.id = "syncing";
        syncingPage.style = "opacity: 0.5";
        syncingPage.src = chrome.extension.getURL("images/loading.gif");
        syncingPage.align = "middle";
        view.appendChild(syncingPage);
    }
    $("#sync-button").unbind('click');

    // render data
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
        //'Authorization':token
    };

    const {
        clusterID,
        orgName,
        region
    } = content;

    const calculateHistoricalCost = (historyData) => {
        const costHistory = {};

        for (var vendor in historyData) {
            costHistory[vendor] = [];
            historyData[vendor].forEach(({
                vmcost,
                vmnum,
                timestamp
            }) => {
                const time = timestamp * 1000;
                costHistory[vendor].push([time, vmcost]);
            });
        }
        return costHistory;
    };

    const calculateHistoricalJITF = (historyData, nowTime) => {
        const numHistory = {};
        jitfResource = {};
        nowHours = nowTime.getUTCHours();
        nowMinutes = nowTime.getUTCMinutes();
        nowSeconds = nowTime.getUTCSeconds();
        for (var vendor in historyData) {
            endOfDay = 0;
            maxNodeNum = 0;
            jitfResource[vendor] = {};
            numHistory[vendor] = [];
            for (let i = 0; i < historyData[vendor].length; i++) {
                const jitfDataTarget = historyData[vendor][i];
                if (Object.keys(jitfDataTarget).length === 0) {
                    console.log("Empty historical JITF");
                    return numHistory;
                }
                if(jitfDataTarget["status"] !== "Empty Result"){
                    for (var key in jitfDataTarget) {
                        const jitfData = jitfDataTarget[key];
                        const instanceType = key;
                        jitfData.forEach(({
                            acc_cost,
                            master_num,
                            worker_num,
                            vm_cost,
                            timestamp,
                        }) => {
                            if (!(timestamp in jitfResource[vendor])) {
                                jitfResource[vendor][timestamp] = {};
                                jitfResource[vendor][timestamp]["acc_cost"] = 0.0;
                                jitfResource[vendor][timestamp]["node_num"] = 0;
                                jitfResource[vendor][timestamp]["vm_cost"] = 0;
                                jitfResource[vendor][timestamp]["master_instancetype"] = "";
                                jitfResource[vendor][timestamp]["worker_instancetype"] = "";
                            }
                            jitfResource[vendor][timestamp]["acc_cost"] += acc_cost;
                            jitfResource[vendor][timestamp]["node_num"] += master_num + worker_num;
                            jitfResource[vendor][timestamp]["vm_cost"] += vm_cost;
                            if ( master_num > 0 && !(jitfResource[vendor][timestamp]["master_instancetype"].includes(instanceType))) {
                                if (jitfResource[vendor][timestamp]["master_instancetype"] === "") {
                                    jitfResource[vendor][timestamp]["master_instancetype"] = instanceType;
                                } else {
                                    jitfResource[vendor][timestamp]["master_instancetype"] = `${jitfResource[vendor][timestamp]["master_instancetype"]}, ${instanceType}`;
                                }
                            }
                            if ( worker_num > 0 && !(jitfResource[vendor][timestamp]["worker_instancetype"].includes(instanceType))) {
                                if (jitfResource[vendor][timestamp]["worker_instancetype"] === "") {
                                    jitfResource[vendor][timestamp]["worker_instancetype"] = instanceType;
                                } else {
                                    jitfResource[vendor][timestamp]["worker_instancetype"] = `${jitfResource[vendor][timestamp]["worker_instancetype"]}, ${instanceType}`;
                                }
                            }
                        });
                    }
                } else {
                    return numHistory;
                }
            }

            Object.keys(jitfResource[vendor]).sort().forEach(function(key, idx, array) {
                const time = key * 1000;
                if (endOfDay === 0) {
                    let tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    /*if(set_days===365){
                        endOfDay = endOfDay + 1000*60*60*24*30;
                    }*/
                    maxNodeNum = 0;
                    totalCost = 0;
                    samples = 0;
                }
                if (endOfDay < time) {
                    samples += 1;
                    maxNodeNum = Math.max(maxNodeNum, jitfResource[vendor][key]["node_num"]);

                    totalCost += jitfResource[vendor][key]["vm_cost"];
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    if(set_days === 365){
                        endOfDay = endOfDay - 1000*60*60*24*30;
                    }
                    numHistory[vendor].push({
                        x: timePoint,
                        y: maxNodeNum,
                        cost: totalCost * 24 / samples,
                        masterInstanceType:jitfResource[vendor][key]["master_instancetype"],
                        workerInstanceType:jitfResource[vendor][key]["worker_instancetype"],
                    });
                    //numHistory[]
                    maxNodeNum = 0;
                    totalCost = 0;
                    samples = 0;
                } else {
                    samples += 1;
                    maxNodeNum = Math.max(maxNodeNum, jitfResource[vendor][key]["node_num"]);
                    totalCost += jitfResource[vendor][key]["vm_cost"];
                }
                if (idx === array.length - 1){
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    numHistory[vendor].push({
                        x: timePoint,
                        y: maxNodeNum,
                        cost: totalCost * 24 / samples,
                        masterInstanceType:jitfResource[vendor][key]["master_instancetype"],
                        workerInstanceType:jitfResource[vendor][key]["worker_instancetype"],
                    });
                }
            });
        }
        return numHistory;
    };

    const calculatePredictedJERIforCurrent = (predictedData, provider, nowTime) => {
        const jeriPredict = {};
        jeriResource = {};
        nowHours = nowTime.getUTCHours();
        nowMinutes = nowTime.getUTCMinutes();
        nowSeconds = nowTime.getUTCSeconds();
        if (predictedData.length===0){
            console.log("PredictedJERI is null")
            jeriResource[provider] = {};
            jeriPredict[provider] = {};
            jeriPredict[provider]["ondemandPredict"] = [];
            jeriPredict[provider]["riPredict"] = [];
            jeriPredict[provider]["riCostPredict"] = [];
            jeriPredict[provider]["ondemandCostPredict"] = [];
            jeriPredict[provider]["accCostPredict"] = {};
            jeriPredict[provider]["master"] = [];
            jeriPredict[provider]["worker"] = [];
            jeriPredict[provider]["region"] = [];
            return jeriPredict;
        }
        const predictedDatas = Object.assign(...predictedData);
        for (var vendor in predictedDatas) {
            endOfDay = 0;
            maxOndemand = 0;
            maxRi = 0;
            totalRiCost = 0;
            totalOnDemandCost = 0;
            jeriResource[vendor] = {};
            jeriPredict[vendor] = {};
            jeriPredict[vendor]["ondemandPredict"] = [];
            jeriPredict[vendor]["riPredict"] = [];
            //jeriPredict[vendor]["riCostPredict"] = [];
            //jeriPredict[vendor]["ondemandCostPredict"] = [];
            //jeriPredict[vendor]["accCostPredict"] = {};
            //jeriPredict[vendor]["master"] = [];
            //jeriPredict[vendor]["worker"] = [];
            //jeriPredict[vendor]["region"] = [];
            let region = "";
            if (Object.keys(predictedDatas[vendor]).length === 0 || predictedDatas[vendor]["status"] === "Empty Result") {
                console.log("predicted JERI of", vendor, "is empty");
                continue;
            }
            for (var key in predictedDatas[vendor]) {
                region = predictedDatas[vendor]["region"];
                if (key === "region") {
                    continue;
                } else {

                    const instanceType = key;

                    const jeriVMNum = predictedDatas[vendor][instanceType];
                    jeriVMNum.forEach(({
                        ri_cost,
                        ondemand_cost,
                        acc_cost,
                        master_ondemand_num,
                        worker_ondemand_num,
                        ondemand_num,
                        master_ri_num,
                        worker_ri_num,
                        ri_num,
                        timestamp,
                        master_num,
                        worker_num,
                        master_storage_size,
                        worker_storage_size,
                    }) => {
                        if (!(timestamp in jeriResource[vendor])) {
                            jeriResource[vendor][timestamp] = {};
                            jeriResource[vendor][timestamp]["ri_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["ondemand_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["acc_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["master_ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["worker_ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["ri_num"] = 0;
                            jeriResource[vendor][timestamp]["master_ri_num"] = 0;
                            jeriResource[vendor][timestamp]["worker_ri_num"] = 0;
                            jeriResource[vendor][timestamp]["region"] = region;
                            jeriResource[vendor][timestamp]["master_instancetype"] = "";
                            jeriResource[vendor][timestamp]["worker_instancetype"] = "";
                        }
                        if ( master_num > 0 && !(jeriResource[vendor][timestamp]["master_instancetype"].includes(instanceType))) {
                            if (jeriResource[vendor][timestamp]["master_instancetype"] === "") {
                                jeriResource[vendor][timestamp]["master_instancetype"] = instanceType;
                                jeriResource[vendor][timestamp]["master"] = master_num;
                                jeriResource[vendor][timestamp]["master_storage_size"] = master_storage_size;
                            } else {
                                jeriResource[vendor][timestamp]["master_instancetype"] = `${jeriResource[vendor][timestamp]["master_instancetype"]}, ${instanceType}`;
                            }
                        }
                        if ( worker_num > 0 && !(jeriResource[vendor][timestamp]["worker_instancetype"].includes(instanceType))) {
                            if (jeriResource[vendor][timestamp]["worker_instancetype"] === "") {
                                jeriResource[vendor][timestamp]["worker_instancetype"] = instanceType;
                                jeriResource[vendor][timestamp]["worker"] = worker_num;
                                jeriResource[vendor][timestamp]["worker_storage_size"] = worker_storage_size;
                            } else {
                                jeriResource[vendor][timestamp]["worker_instancetype"] = `${jeriResource[vendor][timestamp]["worker_instancetype"]}, ${instanceType}`;
                            }
                        }
                        jeriResource[vendor][timestamp]["ri_cost"] += ri_cost;
                        jeriResource[vendor][timestamp]["ondemand_cost"] += ondemand_cost;
                        jeriResource[vendor][timestamp]["acc_cost"] += acc_cost;
                        jeriResource[vendor][timestamp]["ondemand_num"] += ondemand_num;
                        jeriResource[vendor][timestamp]["master_ondemand_num"] += master_ondemand_num;
                        jeriResource[vendor][timestamp]["worker_ondemand_num"] += worker_ondemand_num;
                        jeriResource[vendor][timestamp]["ri_num"] += ri_num;
                        jeriResource[vendor][timestamp]["master_ri_num"] += master_ri_num;
                        jeriResource[vendor][timestamp]["worker_ri_num"] += worker_ri_num;
                    });
                }
            }

            Object.keys(jeriResource[vendor]).sort().forEach(function(key, idx, array) {
                const time = key * 1000;
                if (endOfDay === 0) {
                    let tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    if (set_days === 365){
                        endOfDay = endOfDay+1000*60*60*24*30;
                    }
                    maxOndemand = 0;
                    maxRi = 0;
                    totalRiCost = 0;
                    totalOnDemandCost = 0;
                    samples = 0;
                }

                if (endOfDay < time) {
                    samples += 1;
                    totalRiCost += jeriResource[vendor][key]["ri_cost"];
                    totalOnDemandCost += jeriResource[vendor][key]["ondemand_cost"];
                    lastAccCost = jeriResource[vendor][key]["acc_cost"];
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    if (set_days === 365){
                        endOfDay = endOfDay+1000*60*60*24*30;
                    }
                    jeriPredict[vendor]["ondemandPredict"].push({
                        x: timePoint,
                        y: maxOndemand,
                        cost: totalOnDemandCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    jeriPredict[vendor]["riPredict"].push({
                        x: timePoint,
                        y: maxRi,
                        cost: totalRiCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    /*
                    jeriPredict[vendor]["riCostPredict"].push({
                        x: timePoint,
                        y: totalRiCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["ondemandCostPredict"].push({
                        x: timePoint,
                        y: totalOnDemandCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    */
                    maxOndemand = 0;
                    maxRi = 0;
                    totalRiCost = 0;
                    totalOnDemandCost = 0;
                    samples = 0;
                } else {
                    samples += 1;
                    maxOndemand = Math.max(maxOndemand, jeriResource[vendor][key]["ondemand_num"]);
                    maxRi = Math.max(maxRi, jeriResource[vendor][key]["ri_num"]);
                    totalRiCost += jeriResource[vendor][key]["ri_cost"];
                    totalOnDemandCost += jeriResource[vendor][key]["ondemand_cost"];
                    lastAccCost = jeriResource[vendor][key]["acc_cost"];
                }
                if (idx === array.length - 1){
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    jeriPredict[vendor]["ondemandPredict"].push({
                        x: timePoint,
                        y: maxOndemand,
                        cost: totalOnDemandCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    jeriPredict[vendor]["riPredict"].push({
                        x: timePoint,
                        y: maxRi,
                        cost: totalRiCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    /*
                    jeriPredict[vendor]["riCostPredict"].push({
                        x: timePoint,
                        y: totalRiCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["ondemandCostPredict"].push({
                        x: timePoint,
                        y: totalOnDemandCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["accCostPredict"] = {
                        value: lastAccCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        masterOndemand: jeriResource[vendor][key]["master_ondemand_num"],
                        workerOndemand: jeriResource[vendor][key]["worker_ondemand_num"],
                        masterRi: jeriResource[vendor][key]["master_ri_num"],
                        workerRi: jeriResource[vendor][key]["worker_ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    }
                    */
                }
            });
        }
        return jeriPredict;
    };

    const calculatePredictedJERI = (predictedData, costHistory, provider, nowTime) => {
        const jeriPredict = {};
        jeriResource = {};
        nowHours = nowTime.getUTCHours();
        nowMinutes = nowTime.getUTCMinutes();
        nowSeconds = nowTime.getUTCSeconds();
        if (predictedData.length===0){
            console.log("PredictedJERI is null")
            jeriResource[provider] = {};
            jeriPredict[provider] = {};
            jeriPredict[provider]["ondemandPredict"] = [];
            jeriPredict[provider]["riPredict"] = [];
            jeriPredict[provider]["riCostPredict"] = [];
            jeriPredict[provider]["ondemandCostPredict"] = [];
            jeriPredict[provider]["accCostPredict"] = {};
            jeriPredict[provider]["master"] = [];
            jeriPredict[provider]["worker"] = [];
            jeriPredict[provider]["region"] = [];
            return jeriPredict;
        }
        const predictedDatas = Object.assign(...predictedData);
        for (var vendor in predictedDatas) {
            endOfDay = 0;
            maxOndemand = 0;
            maxRi = 0;
            totalRiCost = 0;
            totalOnDemandCost = 0;
            jeriResource[vendor] = {};
            jeriPredict[vendor] = {};
            jeriPredict[vendor]["ondemandPredict"] = [];
            jeriPredict[vendor]["riPredict"] = [];
            jeriPredict[vendor]["riCostPredict"] = [];
            jeriPredict[vendor]["ondemandCostPredict"] = [];
            jeriPredict[vendor]["accCostPredict"] = {};
            jeriPredict[vendor]["master"] = [];
            jeriPredict[vendor]["worker"] = [];
            jeriPredict[vendor]["region"] = [];
            let region = "";
            if (Object.keys(predictedDatas[vendor]).length === 0 || predictedDatas[vendor]["status"] === "Empty Result") {
                console.log("predicted JERI of", vendor, "is empty");
                continue;
            }
            for (var key in predictedDatas[vendor]) {
                region = predictedDatas[vendor]["region"];
                if (key === "region") {
                    continue;
                } else {

                    const instanceType = key;

                    const jeriVMNum = predictedDatas[vendor][instanceType];
                    jeriVMNum.forEach(({
                        ri_cost,
                        ondemand_cost,
                        acc_cost,
                        master_ondemand_num,
                        worker_ondemand_num,
                        ondemand_num,
                        master_ri_num,
                        worker_ri_num,
                        ri_num,
                        timestamp,
                        master_num,
                        worker_num,
                        master_storage_size,
                        worker_storage_size,
                    }) => {
                        if (!(timestamp in jeriResource[vendor])) {
                            jeriResource[vendor][timestamp] = {};
                            jeriResource[vendor][timestamp]["ri_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["ondemand_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["acc_cost"] = 0.0;
                            jeriResource[vendor][timestamp]["ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["master_ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["worker_ondemand_num"] = 0;
                            jeriResource[vendor][timestamp]["ri_num"] = 0;
                            jeriResource[vendor][timestamp]["master_ri_num"] = 0;
                            jeriResource[vendor][timestamp]["worker_ri_num"] = 0;
                            jeriResource[vendor][timestamp]["region"] = region;
                            jeriResource[vendor][timestamp]["master_instancetype"] = "";
                            jeriResource[vendor][timestamp]["worker_instancetype"] = "";
                        }
                        if ( master_num > 0 && !(jeriResource[vendor][timestamp]["master_instancetype"].includes(instanceType))) {
                            if (jeriResource[vendor][timestamp]["master_instancetype"] === "") {
                                jeriResource[vendor][timestamp]["master_instancetype"] = instanceType;
                                jeriResource[vendor][timestamp]["master"] = master_num;
                                jeriResource[vendor][timestamp]["master_storage_size"] = master_storage_size;
                            } else {
                                jeriResource[vendor][timestamp]["master_instancetype"] = `${jeriResource[vendor][timestamp]["master_instancetype"]}, ${instanceType}`;
                            }
                        }
                        if ( worker_num > 0 && !(jeriResource[vendor][timestamp]["worker_instancetype"].includes(instanceType))) {
                            if (jeriResource[vendor][timestamp]["worker_instancetype"] === "") {
                                jeriResource[vendor][timestamp]["worker_instancetype"] = instanceType;
                                jeriResource[vendor][timestamp]["worker"] = worker_num;
                                jeriResource[vendor][timestamp]["worker_storage_size"] = worker_storage_size;
                            } else {
                                jeriResource[vendor][timestamp]["worker_instancetype"] = `${jeriResource[vendor][timestamp]["worker_instancetype"]}, ${instanceType}`;
                            }
                        }
                        jeriResource[vendor][timestamp]["ri_cost"] += ri_cost;
                        jeriResource[vendor][timestamp]["ondemand_cost"] += ondemand_cost;
                        jeriResource[vendor][timestamp]["acc_cost"] += acc_cost;
                        jeriResource[vendor][timestamp]["ondemand_num"] += ondemand_num;
                        jeriResource[vendor][timestamp]["master_ondemand_num"] += master_ondemand_num;
                        jeriResource[vendor][timestamp]["worker_ondemand_num"] += worker_ondemand_num;
                        jeriResource[vendor][timestamp]["ri_num"] += ri_num;
                        jeriResource[vendor][timestamp]["master_ri_num"] += master_ri_num;
                        jeriResource[vendor][timestamp]["worker_ri_num"] += worker_ri_num;
                    });
                }
            }

            Object.keys(jeriResource[vendor]).sort().forEach(function(key, idx, array) {
                const time = key * 1000;
                if (endOfDay === 0) {
                    let tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    if (set_days === 365){
                        endOfDay = endOfDay+1000*60*60*24*30;
                    }
                    maxOndemand = 0;
                    maxRi = 0;
                    totalRiCost = 0;
                    totalOnDemandCost = 0;
                    samples = 0;
                }

                if (endOfDay < time) {
                    samples += 1;
                    totalRiCost += jeriResource[vendor][key]["ri_cost"];
                    totalOnDemandCost += jeriResource[vendor][key]["ondemand_cost"];
                    lastAccCost = jeriResource[vendor][key]["acc_cost"];
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    if (set_days === 365){
                        endOfDay = endOfDay+1000*60*60*24*30;
                    }
                    jeriPredict[vendor]["ondemandPredict"].push({
                        x: timePoint,
                        y: maxOndemand,
                        cost: totalOnDemandCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    jeriPredict[vendor]["riPredict"].push({
                        x: timePoint,
                        y: maxRi,
                        cost: totalRiCost * 24 / samples,
                        masterInstanceType: jeriResource[vendor][key]["master_instancetype"],
                        workerInstanceType: jeriResource[vendor][key]["worker_instancetype"],
                    });
                    jeriPredict[vendor]["riCostPredict"].push({
                        x: timePoint,
                        y: totalRiCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["ondemandCostPredict"].push({
                        x: timePoint,
                        y: totalOnDemandCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    maxOndemand = 0;
                    maxRi = 0;
                    totalRiCost = 0;
                    totalOnDemandCost = 0;
                    samples = 0;
                } else {
                    samples += 1;
                    maxOndemand = Math.max(maxOndemand, jeriResource[vendor][key]["ondemand_num"]);
                    maxRi = Math.max(maxRi, jeriResource[vendor][key]["ri_num"]);
                    totalRiCost += jeriResource[vendor][key]["ri_cost"];
                    totalOnDemandCost += jeriResource[vendor][key]["ondemand_cost"];
                    lastAccCost = jeriResource[vendor][key]["acc_cost"];
                }
                if (idx === array.length - 1){
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds, 0);
                    timePoint = tmp.getTime();
                    jeriPredict[vendor]["ondemandPredict"].push({
                        x: timePoint,
                        y: maxOndemand,
                        cost: totalOnDemandCost * 24 / samples,
                    });
                    jeriPredict[vendor]["riPredict"].push({
                        x: timePoint,
                        y: maxRi,
                        cost: totalRiCost * 24 / samples,
                    });
                    jeriPredict[vendor]["riCostPredict"].push({
                        x: timePoint,
                        y: totalRiCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["ondemandCostPredict"].push({
                        x: timePoint,
                        y: totalOnDemandCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        ondemand: jeriResource[vendor][key]["ondemand_num"],
                        ri: jeriResource[vendor][key]["ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        accCost: lastAccCost,
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    });
                    jeriPredict[vendor]["accCostPredict"] = {
                        value: lastAccCost,
                        master: jeriResource[vendor][key]["master"],
                        worker: jeriResource[vendor][key]["worker"],
                        region: jeriResource[vendor][key]["region"],
                        masterOndemand: jeriResource[vendor][key]["master_ondemand_num"],
                        workerOndemand: jeriResource[vendor][key]["worker_ondemand_num"],
                        masterRi: jeriResource[vendor][key]["master_ri_num"],
                        workerRi: jeriResource[vendor][key]["worker_ri_num"],
                        masterInstancetype: jeriResource[vendor][key]["master_instancetype"],
                        workerInstancetype: jeriResource[vendor][key]["worker_instancetype"],
                        provider: providerMapping[vendor],
                        masterStorageSize: jeriResource[vendor][key]["master_storage_size"],
                        workerStorageSize: jeriResource[vendor][key]["worker_storage_size"],
                    }
                }
            });
        }
        return jeriPredict;
    };

    const calculatePredictedVMCost = (predictedData, costHistory, provider, currentInfo, nowTime) => {
        const VMCostArray = {};
        nowHours = nowTime.getUTCHours();
        nowMinutes = nowTime.getUTCMinutes();
        nowSeconds = nowTime.getUTCSeconds();
        for (var vendor in predictedData) {
            VMCostArray[vendor] = {};
            VMCostArray[vendor]["vmCost"] = [];
            VMCostArray[vendor]["accCost"] = {};
            totalCost = 0;
            endOfDay = 0;
            predictedData[vendor].forEach(({
                vmcost,
                acc_cost,
                vmnum,
                timestamp,
                master_storage_size,
                worker_storage_size,
            }, idx, array) => {
                const time = timestamp * 1000;
                if (endOfDay === 0) {
                    let tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    totalCost = 0;
                }
                if (endOfDay < time) {
                    totalCost += vmcost;
                    lastAccCost = acc_cost;
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds);
                    timePoint = tmp.getTime();
                    tmp = new Date(time);
                    tmp.setUTCHours(23,59,59);
                    endOfDay = tmp.getTime();
                    VMCostArray[vendor]["vmCost"].push({
                        x: timePoint,
                        y: totalCost,// + costOffset,
                        master: currentInfo.mastersCount,
                        worker: currentInfo.workersCount,
                        region: currentInfo.region,
                        masterInstanceType: currentInfo.masterInstanceType,
                        workerInstanceType: currentInfo.workerInstanceType,
                        provider: providerMapping[vendor],
                    });
                    totalCost = 0;
                } else {
                    totalCost += vmcost;
                    lastAccCost = acc_cost;
                }
                if (idx === array.length - 1){
                    let tmp = new Date(endOfDay);
                    tmp.setUTCHours(nowHours, nowMinutes, nowSeconds);
                    timePoint = tmp.getTime();
                    VMCostArray[vendor]["vmCost"].push({
                        x: timePoint,
                        y: totalCost,// + costOffset,
                        master: currentInfo.mastersCount,
                        worker: currentInfo.workersCount,
                        region: currentInfo.region,
                        masterInstanceType: currentInfo.masterInstanceType,
                        workerInstanceType: currentInfo.workerInstanceType,
                        provider: providerMapping[vendor],
                    });
                    VMCostArray[vendor]["accCost"] = {
                        value: lastAccCost,
                        master: currentInfo.mastersCount,
                        worker: currentInfo.workersCount,
                        region: currentInfo.region,
                        masterInstanceType: currentInfo.masterInstanceType,
                        workerInstanceType: currentInfo.workerInstanceType,
                        provider: providerMapping[vendor],
                        masterStorageSize: master_storage_size,
                        workerStorageSize: worker_storage_size,
                    };
                }
            });
        }
        return VMCostArray;
    };

    const setResourceUtilization = (clusterName, provider, historiesWorkload, predictionsWorkload) => {
        var totalResource = {};
        var totalCpu = 0.0;
        var totalMemory = 0.0;

        const cpuHistory = {};
        const memHistory = {};

        const cpuPredict = {};
        const memPredict = {};

        const historicalData = historiesWorkload.resource[clusterName];
        for (var vendor in historicalData) {
            cpuHistory[vendor] = [];
            memHistory[vendor] = [];
            totalResource[vendor] = {};
            totalCpu = 0.0;
            totalMemory = 0.0;
            for (let i = 0; i < historicalData[vendor].length; i++) {
                const historiesDataTarget = historicalData[vendor][i];
                const historiesData = historiesDataTarget[Object.keys(historiesDataTarget)[0]].utilization;
                totalCpu += historiesDataTarget[Object.keys(historiesDataTarget)[0]]["cpu_cores"];
                totalMemory += historiesDataTarget[Object.keys(historiesDataTarget)[0]]["memory_total"];
                historiesData.forEach(({
                    cpu,
                    memory,
                    timestamp
                }) => {
                    if (!(timestamp in totalResource[vendor])) {
                        totalResource[vendor][timestamp] = {};
                        totalResource[vendor][timestamp]["cpu"] = 0.0;
                        totalResource[vendor][timestamp]["memory"] = 0.0;
                    }
                    totalResource[vendor][timestamp]["cpu"] += cpu;
                    totalResource[vendor][timestamp]["memory"] += memory;
                });
            }

            Object.keys(totalResource[vendor]).sort().forEach(function(key) {
                const time = key * 1000;
                var Cpu = totalResource[vendor][key]["cpu"] / totalCpu
                var Memory = totalResource[vendor][key]["memory"] / totalMemory
                cpuHistory[vendor].push([time, Cpu * 100]);
                memHistory[vendor].push([time, Memory * 100]);
            });
        }

        totalResource = {};
        const predictedData = predictionsWorkload.resource[clusterName];
            for (var vendor in predictedData) {
                cpuPredict[vendor] = [];
                memPredict[vendor] = [];
                totalResource[vendor] = {};
                totalCpu = 0.0;
                totalMemory = 0.0;
                for (let i = 0; i < predictedData[vendor].length; i++) {
                    const predictionDataTarget = predictedData[vendor][i];
                    const predictionData = predictionDataTarget[Object.keys(predictionDataTarget)[0]].utilization;
                    totalCpu += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["cpu_cores"];
                    totalMemory += predictionDataTarget[Object.keys(predictionDataTarget)[0]]["memory_total"];
                    predictionData.forEach(({
                        cpu,
                        memory,
                        timestamp
                    }) => {
                        if (!(timestamp in totalResource[vendor])) {
                            totalResource[vendor][timestamp] = {};
                            totalResource[vendor][timestamp]["cpu"] = 0.0;
                            totalResource[vendor][timestamp]["memory"] = 0.0;
                        }
                        totalResource[vendor][timestamp]["cpu"] += cpu;
                        totalResource[vendor][timestamp]["memory"] += memory;
                    });
                }

                Object.keys(totalResource[vendor]).sort().forEach(function(key) {
                    const time = key * 1000;
                    var Cpu = totalResource[vendor][key]["cpu"] / totalCpu
                    var Memory = totalResource[vendor][key]["memory"] / totalMemory
                    cpuPredict[vendor].push([time, Cpu * 100]);
                    memPredict[vendor].push([time, Memory * 100]);
                });
            }
            cacheCpuHistory = cpuHistory[provider];
            cacheCpuPredict = cpuPredict[provider];
            cacheMemHistory = memHistory[provider];
            cacheMemPredict = memPredict[provider];
            setCpuMemChart(cpuHistory[provider], memHistory[provider], cpuPredict[provider], memPredict[provider]);
        };

    const setRequiredVMNumbersAndCost = (totalCount, clusterName, provider, currentInfo, historiesVMCost, historiesJITF, predictionsJERIforCurrent, predictionsJERI, predictionsVMCost, currentCost) => {
        let nowTime = new Date();
        const costHistory = calculateHistoricalCost(historiesVMCost.resource[clusterName]);
        const numHistory = calculateHistoricalJITF(historiesJITF.resource[clusterName], nowTime);
        const jeriPredictforCurrent = calculatePredictedJERIforCurrent(predictionsJERIforCurrent.resource[clusterName][provider], provider, nowTime);
        const jeriPredict = calculatePredictedJERI(predictionsJERI.resource[clusterName][provider], costHistory, provider, nowTime);
        const VMCostArray = calculatePredictedVMCost(predictionsVMCost.resource[clusterName], costHistory, provider, currentInfo, nowTime);
        const currentTime = Date.now();
        const days = set_days;
        const min = currentTime - (days * 24 * 60 * 60 * 1000) - 1;
        totalCountSeries = [];
        if (days === 7){
            count = 86400;
        }else if (days === 365){
            count = 60*60*24*30
        }
        for (var t = min; t < currentTime; t += count) {
            totalCountSeries.push([t, totalCount]);
        }
        setNumOfVMChart(totalCountSeries, numHistory[provider], jeriPredictforCurrent[provider]["ondemandPredict"], jeriPredictforCurrent[provider]["riPredict"]);
        setMonthlyCostChart(VMCostArray[provider]["accCost"], jeriPredict, currentCost, provider);
        collapseImg = document.getElementById('collapse-chart');
        collapseImg.style.display = "block";
    };

    const setDetailView = (data, provider, public_api, currentInfo) => {
        const api = `${public_api}`;
        const method = 'PUT';
        cacheData = data;

        // Historical Workload
        const historyUtilization = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'historical',
                    type: 'workload',
                }),

            ],
        });

        // Predicted Workload
        const predictedUtilization = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'predicted',
                    type: 'workload',
                })
            ],
        });

        // Historical VMCost
        const historyVMCost = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'historical',
                    type: 'vmcost'
                })
            ],
        });

        // Historical JITF
        const historyJITF = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'historical',
                    type: 'jitf'
                })
            ],
        });

        // Predicted JERI for current configuration
        const predictedJERIforCurrent = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    acceptance: [
                      {
                        provider: "-"
                      }
                    ],
                    category: 'predicted',
                    type: 'jeri'
                })
            ],
        });

        // Predicted JERI
        const predictedJERI = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'predicted',
                    type: 'jeri'
                })
            ],
        });

        // Predicted VMCost
        const predictedVMCostData = JSON.stringify({
            resource: [
                Object.assign({}, data, {
                    category: 'predicted',
                    type: 'vmcost'
                })
            ],
        });
                //Current Cost
        var courrentdata = {};
        currentdata = data["nodesinfo"]
        for (var setunit in currentdata[provider]){
            currentdata[provider][setunit]["instances"]["unit"] = "month";
            for (var temp in currentdata[provider][setunit]["storage"]){
                currentdata[provider][setunit]["storage"][temp]["unit"] = "month";
            }
        }
        const currentCostData = JSON.stringify({
            calculator: [
                Object.assign({}, currentdata, {
                })
            ],
        });
        var timestamp = Math.floor(Date.now()/1000);
        if (set_days === 7){
            predict_tsfrom = timestamp;
            predict_tsto = timestamp + 60*60*24*7;
            history_tsfron = timestamp - 60*60*24*7;
            history_tsto = timestamp;
            granularity = 3600;
            fill_days = 7;
         } else if (set_days === 365){
            predict_tsfrom =timestamp;
            predict_tsto =timestamp + 60*60*24*365;
            history_tsfron =timestamp - 60*60*24*120;
            history_tsto =timestamp;
            granularity = 86400;
            fill_days = 365;
         }


        var requestsList = [];
        requestsList.push({
          url: `${api}/resources/historical/workloads?tsfrom=${history_tsfron}&tsto=${history_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: historyUtilization
          })
        });
        requestsList.push({
          url: `${api}/resources/predictions/workloads?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: predictedUtilization
          })
        });
        requestsList.push({
          url: `${api}/resources/historical/vm-cost?tsfrom=${history_tsfron}&tsto=${history_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: historyVMCost
          })
        });
        requestsList.push({
          url: `${api}/resources/historical/jitf?tsfrom=${history_tsfron}&tsto=${history_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: historyJITF
          })
        });
        requestsList.push({
          url: `${api}/recommendations/jeri?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: predictedJERIforCurrent
          })
        });
        requestsList.push({
          url: `${api}/recommendations/jeri?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: predictedJERI
          })
        });
        requestsList.push({
          url: `${api}/resources/predictions/vm-cost?tsfrom=${predict_tsfrom}&tsto=${predict_tsto}&granularity=${granularity}&fill_days=${fill_days}`,
          body: Object.assign({}, {
              headers,
              method,
              body: predictedVMCostData
          })
        });
        requestsList.push({
            url: `${api}/calculators/`,
            body: Object.assign({}, {
                headers,
                method,
                body: currentCostData
            })
        });

        var historiesWorkload = {};
        var predictionsWorkload = {};
        var historiesVMCost = {};
        var historiesJITF = {};
        var predictionsJERIforCurrent = {};
        var predictionsJERI = {};
        var predictionsVMCost = {};
        var currentCost = {};

        chrome.runtime.sendMessage({
            "method": "parallel_post_request",
            "requests": requestsList,
        }, (response) => {
            loadingImg = document.getElementById('loading');
            loadingImg.style.display = "none";
            if (response["status"] != 200) {
                console.log(response["error"]);
                console.log("Error occurred during setDetailView");
                const jeriEmpty = {
                    gcp: {
                        riCostPredict: [],
                        ondemandCostPredict: []
                    },
                    aws: {
                        riCostPredict: [],
                        ondemandCostPredict: []
                    },
                    azure: {
                        riCostPredict: [],
                        ondemandCostPredict: []
                    }
                };
                setCostChart([], jeriEmpty);
                setCpuMemChart([], [], [], []);
                setNumOfVMChart(0, [], [], []);
                return
            }
            var results = response["results"];
            console.log("Query Response from API successfully");
            historiesWorkload = results[0];
            predictionsWorkload = results[1];
            historiesVMCost = results[2];
            historiesJITF = results[3];
            predictionsJERIforCurrent = results[4];
            predictionsJERI = results[5];
            predictionsVMCost = results[6];
            currentCost = results[7];
            console.log("Historical Workload");
            console.log(historiesWorkload);
            console.log("Predicted Workload");
            console.log(predictionsWorkload);
            console.log("Historical VMCost");
            console.log(historiesVMCost);
            console.log("Historical JITF");
            console.log(historiesJITF);
            console.log("Predicted JERI for Current");
            console.log(predictionsJERIforCurrent);
            console.log("Predicted JERI");
            console.log(predictionsJERI);
            console.log("Predicted VMCost");
            console.log(predictionsVMCost);
            console.log("Current Cost");
            console.log(currentCost);

            const totalCount = data.nodesinfo[Object.keys(data.nodesinfo)[0]].length;
            const clusterName = data.clustername;
            Isloading=false;
            setResourceUtilization(clusterName, provider, historiesWorkload, predictionsWorkload);
            setRequiredVMNumbersAndCost(totalCount, clusterName, provider, currentInfo, historiesVMCost, historiesJITF, predictionsJERIforCurrent, predictionsJERI, predictionsVMCost, currentCost);
            if (loading) {
                view.removeChild(syncingPage);
            }
            $("#sync-button").bind('click', syncPage);
        });
    }

    const cluster = async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        const fetchOrgID = await fetch('https://api.nks.netapp.io/orgs', Object.assign({}, {
            headers,
            method: 'GET'
        }));
        const resultOrgID = await fetchOrgID.json();
        const orgID = resultOrgID.filter(({
            name
        }) => name === orgName)[0].pk;
        const fetchCluster = await fetch(`https://api.nks.netapp.io/orgs/${orgID}/clusters`, Object.assign({}, {
            headers,
            method: 'GET'
        }));
        const resultCluster = await fetchCluster.json();

        return resultCluster.filter(({
            pk
        }) => pk === Number(clusterID))[0];
    };

    cluster()
        .then(({
            name = '',
            provider = 'aws',
            nodes = []
        }) => {
            let volume_type_raw = 'General Purpose';
            let os_type_raw = 'Linux';
            if (provider === 'gce') {
                provider = 'gcp';
                os_type_raw = 'free';
                volume_type_raw = GCP_volume_type;
            } else if (provider === 'aws') {
                volume_type_raw = AWS_volume_type;
            } else if (provider === 'azure') {
                volume_type_raw = Azure_volume_type;
            }
            const data = {
                name,
                provider,
                region,
                masters: [],
                workers: [],
            };

            const masters = nodes.filter(({
                role,
                state
            }) => role === 'master' && state !== 'deleted');
            const workers = nodes.filter(({
                role,
                state
            }) => role === 'worker' && state !== 'deleted');
            const mastersCount = masters.length;
            const workersCount = workers.length;
            let public_api = `${api_base}`;
            if (masters.length > 0) {
                const public_ip = masters[0].public_ip;
                //public_api = `https://${public_ip}/fedemeter-api/v1`;
                public_api = `http://${public_ip}:31000/fedemeter-api/v1`;
            }

            masters.forEach(({
                public_ip,
                private_ip,
                instance_id,
                root_disk_size,
                size,
            }) => {
                let nodename = instance_id;
                if (provider === 'aws') {
                    nodename = private_ip;
                }
                data.masters.push({
                    host: public_ip,
                    nodename: nodename,
                    instancetype: size.replace(/\s+/g, '-').replace(/\_/g, '-'),
                    instancenum: mastersCount,
                    storagesize: root_disk_size,
                    storagenum: mastersCount,
                    volume_type: volume_type_raw,
                    os_type: os_type_raw,
                });
            });
            workers.forEach(({
                public_ip,
                private_ip,
                instance_id,
                root_disk_size,
                size,
            }) => {
                let nodename = instance_id;
                if (provider === 'aws') {
                    nodename = private_ip;
                }
                data.workers.push({
                    host: public_ip,
                    nodename: nodename,
                    instancetype: size.replace(/\s+/g, '-').replace(/\_/g, '-'),
                    //instancenum: workersCount,
                    instancenum: "1",
                    storagesize: root_disk_size,
                    //storagenum: workersCount,
                    storagenum: "1",
                    volume_type: volume_type_raw,
                    os_type: os_type_raw,
                });
            });

            data.host = data.masters.map(({
                host
            }) => host);
            return {
                data: data,
                public_api: public_api,
            };
        })
        .then((result) => {
            const {
                data,
                public_api,
            } = result;
            const {
                host,
                masters,
                name,
                provider,
                region,
                workers,
            } = data;

            const nodesInfo = [];
            masters.forEach((master) => {
                const {
                    nodename,
                    instancetype,
                    instancenum,
                    storagesize,
                    storagenum,
                    volume_type,
                    os_type,
                    //gpuinstance,
                    //gpunum,
                } = master;
                let obj = {
                    region,
                    instances: {
                        nodename: nodename.split('.').join('-'),
                        instancetype,
                        nodetype: "master",
                        operatingsystem: os_type,
                        preinstalledsw: "NA",
                        instancenum: String(instancenum),
                        period: "1",
                        unit: "hour"
                    },
                    storage: [{
                        volumetype: volume_type,
                        storagesize: String(storagesize),
                        storagenum: String(storagenum),
                        period: "1",
                        unit: "hour",
                    }],
                };
                /*if (gpunum != "0") {
                    obj = Object.assign(obj,{
                        gpu: {
                            gpuinstance,
                            gpunum,
                            period: "1",
                            unit: "hour",
                        }
                    })
                }*/
                nodesInfo.push(obj);
            });
            workers.forEach((worker) => {
                const {
                    nodename,
                    instancetype,
                    instancenum,
                    storagesize,
                    storagenum,
                    volume_type,
                    os_type,
                    //gpuinstance,
                    //gpunum,
                } = worker;
                let obj = {
                    region,
                    instances: {
                        nodename: nodename.split('.').join('-'),
                        instancetype,
                        nodetype: "worker",
                        operatingsystem: os_type,
                        preinstalledsw: "NA",
                        instancenum: String(instancenum),
                        period: "1",
                        unit: "hour"
                    },
                    storage: [{
                        volumetype: volume_type,
                        storagesize: String(storagesize),
                        storagenum: String(storagenum),
                        period: "1",
                        unit: "hour",
                    }],
                };
                /*if (gpunum != "0") {
                    obj = Object.assign(obj,{
                        gpu: {
                            gpuinstance,
                            gpunum,
                            period: "1",
                            unit: "hour",
                        }
                    })
                }*/
                nodesInfo.push(obj);
            });

            const resources = {
                category: "",
                type: "",
                clustername: name,
                // host,
                // port: "30537",
                nodesinfo: {
                    [provider]: nodesInfo,
                },
            };

            return {
                data: resources,
                provider: provider,
                public_api: public_api,
                mastersCount: masters.length,
                workersCount: workers.length,
                region: region,
                masterInstanceType: masters[0].instancetype,
                workerInstanceType: workers[0].instancetype,
            };
        })
        .then((result) => {
            const {
                data,
                provider,
                public_api,
                mastersCount,
                workersCount,
                region,
                masterInstanceType,
                workerInstanceType,
            } = result;

            const currentInfo = {
                mastersCount: mastersCount,
                workersCount: workersCount,
                masterInstanceType: masterInstanceType,
                workerInstanceType: workerInstanceType,
                region: region,
            };

            /*console.log("data")
            console.log(data)
            console.log("provider")
            console.log(provider)
            console.log("public_api")
            console.log(public_api)
            console.log("currentInfo")
            console.log(currentInfo)*/
            cachedProvider=provider;
            cacheAPI=public_api;
            setDetailView(data, provider, public_api, currentInfo);
        });
};



const removeInjectView = () => {
    currentPage = "";
    cachedProvider = "";
    cachedRegion = "";
    cachedMaster = {};
    cachedWorker = {};

    const jeriEmpty = {
        gcp: {
            riCostPredict: [],
            ondemandCostPredict: []
        },
        aws: {
            riCostPredict: [],
            ondemandCostPredict: []
        },
        azure: {
            riCostPredict: [],
            ondemandCostPredict: []
        }
    };
    setCostChart([], jeriEmpty);
    setCpuMemChart([], [], [], []);
    setNumOfVMChart(0, [], [], []);
    IsPin=false;
    console.log("Remove inject view");
    //var cover = document.getElementsByClassName("domain-netapp");


    while (view.firstChild) {
        view.removeChild(view.firstChild);
    }
    if (document.getElementById(viewId)) {
        cover.removeChild(view);
    }
};

const updateView = (page, content) => {
    removeInjectView();
    checkAndLaunchUrl(page, content);
};

const sleep = (milliseconds) => {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
            break;
        }
    }
};

const objectCompare = (obj1, obj2) => {
    //Loop through properties in object 1
    for (var p in obj1) {
        //Check property exists on both objects
        if (obj1.hasOwnProperty(p) !== obj2.hasOwnProperty(p)) return false;

        switch (typeof (obj1[p])) {
            //Deep compare objects
            case 'object':
                return JSON.stringify(obj1[p]) === JSON.stringify(obj2[p])
                break;
            //Compare function code
            case 'function':
                if (typeof (obj2[p]) == 'undefined' || (p != 'compare' && obj1[p].toString() != obj2[p].toString())) return false;
                break;
            //Compare values
            default:
                if (obj1[p] != obj2[p]) return false;
        }
    }

    //Check object 2 for any extra properties
    for (var p in obj2) {
        if (typeof (obj1[p]) == 'undefined') return false;
    }
    return true;
};

var RegularCheckPageInterval = setInterval(function() {
    if (currentPage === "new" || currentPage === "choose-provider") {
        const {
            page,
            content
        } = getPathName();
        //console.log(`currentPage ${currentPage} page ${page}`);
        if (currentPage === "new" && page === "choose-provider") {
            currentPage = page;
            updateView(page, content);
        } else if (currentPage === "choose-provider" && page ==="new") {
            currentPage = page;
            updateView(page, content);
        }
    }
}, checkPageInterval);

var RegularSyncDetailResultInterval = setInterval(function() {
    if(IsSetting){
        console.log("Is setting");
    } else{
        if (currentPage === "detail") {
            const {
                page,
                content
            } = getPathName();
            renderDetailPage(content, false);
        }
    }
}, syncDetailResultInterval);

var RegularRecalculateResultInterval = setInterval(function() {
    if (currentPage === "new") {
        const {
            page,
            content
        } = getPathName();
        const {
            provider,
            region,
            master,
            worker,
        } = content;

        if (cachedProvider === "") {
            cachedProvider = provider;
            cachedRegion = region;
            cachedMaster = master;
            cachedWorker = worker;
            console.log("Initialize cache");
            renderNewPage(content, false);
        } else if (cachedProvider === provider && cachedRegion === region && objectCompare(cachedMaster, master) && objectCompare(cachedWorker, worker)) {
            console.log("Same configuration, skip update");
        } else {
            console.log("Content change, update view");
            cachedProvider = provider;
            cachedRegion = region;
            cachedMaster = master;
            cachedWorker = worker;
            renderNewPage(content, false);
        }
    }
}, calculateResultInterval);

chrome.extension.onMessage.addListener( (message) => {
    action = message.action;
    const {
        page,
        content
    } = getPathName();

    if (action === "inject") {
        const {
            provider,
            region,
            master,
            worker,
        } = content;
        cachedProvider = provider;
        cachedRegion = region;
        cachedMaster = master;
        cachedWorker = worker;
        checkAndLaunchUrl(page, content);
    } else if (action === "remove") {
        removeInjectView();
    } else if (action === "update") {
        updateView(page, content);
    }
});

const setCpuMemChart = (cpuHistory, memHistory, cpuPredict, memPredict) => {
    const currentTime = Date.now();
    const days = set_days;
    var min=0;
    if (days === 365){
        min = currentTime - (120 * 24 * 60 * 60 * 1000);
    } else {
        min = currentTime - (days * 24 * 60 * 60 * 1000);
    }
    const max = currentTime + (days * 24 * 60 * 60 * 1000);
    plotLineId = 'clusterCapacityLine'
    plotLineOptions = {
        id: plotLineId,
        value: 100,
        width: 2,
        dashStyle: 'ShortDash',
        color: '#5cc770',
        label: {
            text: 'Cluster Capacity',
            y: 20
        },
        zIndex: 5,
    };
    $('#cpu-and-memory-chart').highcharts({
        chart: {
            height: 187,
            width: 600,
            type: 'spline',
            plotBorderWidth: 1,
            marginRight: 10,
        },
        title: {
            margin: 0,
            text: 'Resource Utilization for Managed Pods',
        },
        xAxis: {
            type: 'datetime',
            tickPixelInterval: 80,
            plotLines: [{
                color: '#23b0a2',
                width: 2,
                dashStyle: 'ShortDash',
                label: {
                    text: 'Now',
                },
                value: new Date().getTime(),
                zIndex: 5,
            }],
            min,
            max,
        },
        yAxis: [{
            labels: {
                useHTML:true,
                style:{
                    width:'40px',
                    whiteSpace:'normal'
                },
                formatter: function () {
                    return '<div align="right" style="word-wrap: break-word;word-break: break-all;width:40px">' + this.value + ' %</div>';
                }
            },
            title: {
                text: null,
            },
            maxPadding: 0,
            plotLines: [],
            tickAmount: 6,
        }],
        tooltip: {
            shared: true,
            crosshairs: true,
            useHTML: true,
            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:.2f} %</b><br/>',
            headerFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                '<b>{point.point.symbolName}</b><br>',
        },
        legend: {
            margin: 2,
            align: 'left',
            verticalAlign: 'top',
            borderWidth: 0,
            itemDistance: 10,
        },
        exporting: {
            enabled: false
        },
        series: [{
                color: '#0086b3',
                name: 'CPU',
                tooltip: {
                    valueSuffix: ' %'
                },
                data: cpuHistory,
                display: 'block',
                marker: {
                    symbol: "circle"
                }
            },
            {
                color: '#00bfff',
                name: 'Memory',
                tooltip: {
                    valueSuffix: ' %'
                },
                data: memHistory,
                display: 'block',
                marker: {
                    symbol: "diamond"
                }
            },
            {
                color: '#e22e5d',
                name: 'CPU Predicted',
                tooltip: {
                    valueSuffix: ' %'
                },
                dashStyle: 'ShortDot',
                data: cpuPredict,
                display: 'none',
                marker: {
                    symbol: "circle"
                }
            },
            {
                color: '#fc7095',
                name: 'Memory Predicted',
                tooltip: {
                    valueSuffix: ' %'
                },
                dashStyle: 'ShortDot',
                data: memPredict,
                display: 'none',
                marker: {
                    symbol: "diamond"
                }
            },
            {
                color: '#5cc770',
                name: 'Cluster Capacity',
                marker: {
                    enabled: false
                },
                dashStyle: 'ShortDash',
                events: {
                    // Event for showing/hiding plot line
                    legendItemClick: function(e) {
                        if (this.visible) {
                            this.chart.yAxis[0].removePlotLine(plotLineId);
                            this.chart.yAxis[0].setExtremes(null, null);
                        } else {
                            this.chart.yAxis[0].addPlotLine(plotLineOptions);
                            this.chart.yAxis[0].setExtremes(null, 100);
                        }
                    },
                    afterAnimate: function() {
                        this.chart.yAxis[0].addPlotLine(plotLineOptions);
                        this.chart.yAxis[0].setExtremes(null, 100);
                    }
                }
            },
        ],
    });
};

const setNumOfVMChart = (totalCountSeries, numHistory, ondemandPredict, riPredict) => {
    const currentTime = Date.now();
    const days = set_days;

    var min;
    if (days === 365){
        min = currentTime - (120 * 24 * 60 * 60 * 1000);
    } else {
        min = currentTime - (days * 24 * 60 * 60 * 1000);
    }
    const max = currentTime + (days * 24 * 60 * 60 * 1000);

    if (set_days===365){
        for (var index in numHistory){
            numHistory[index]["cost"] = numHistory[index]["cost"]*30;
        }
        for (var index in riPredict){
            riPredict[index]["cost"] = riPredict[index]["cost"]*30;
        }
        format = '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} node(s), ${point.cost:.2f}/month</b><br/>';
    } else {
        format = '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} node(s), ${point.cost:.2f}/day</b><br/>';
    }

    $('#num-of-vms-chart').highcharts({
        chart: {
            height: 187,
            width: 600,
            type: 'column',
            plotBorderWidth: 1,
            marginRight: 10,
        },
        title: {
            margin: 0,
            text: 'Recommendation for Reserved Instance Commitments',
        },
        xAxis: {
            type: 'datetime',
            tickPixelInterval: 160,
            plotLines: [{
                color: '#23b0a2',
                width: 2,
                dashStyle: 'ShortDash',
                label: {
                    text: 'Now'
                },
                value: new Date().getTime(),
                zIndex: 5,
            }],
            min,
            max,
            minPadding: 0,
            maxPadding: 0,
        },
        yAxis: {
            title: {
                text: null,
            },
            //plotLines: [{
            //    value: totalCount,
            //    width: 3,
            //    color: '#5cc770',
            //    dashStyle: 'ShortDash',
            //    label: {
            //        text: 'Cluster Allocated',
            //        y: 20,
            //    }
            //}],
            labels: {
                useHTML:true,
                style:{
                    width:'40px',
                    whiteSpace:'normal'
                },
                formatter: function () {
                    return '<div align="right" style="word-wrap: break-word;word-break: break-all;width:40px">' + this.value + '</div>';
                }
            },
            tickInterval: 2,
            allowDecimals: false,
        },
        tooltip: {
            shared: true,
            formatter: function() {
                var pformat;
                var isHeaderSet=false;
                this.points.forEach((point) => {
                    if(!isHeaderSet){
                        pformat = '<small>'+Highcharts.dateFormat('%A, %b %e, %H:%M',
                            new Date(this.x))+'</small><br>'
                            + "Master Instance Type: <b>"+ point.point.masterInstanceType +'</b><br>'
                            + 'Woker Instance Type: <b>'+point.point.workerInstanceType+ '</b><br>';
                        isHeaderSet=true;
                    }
                    if (set_days===365){
                        pformat += '<span style="color:'+point.series.color+'">'+point.series.name+'</span>: <b>'+point.y+' node(s), $'+Number.parseFloat(point.point.cost).toFixed(2)+'/month</b><br/>';
                    } else {
                        pformat += '<span style="color:'+point.series.color+'">'+point.series.name+'</span>: <b>'+point.y+' node(s), $'+Number.parseFloat(point.point.cost).toFixed(2)+'/day</b><br/>';
                    }
                });
                return pformat;
            },
        },
        legend: {
            margin: 2,
            align: 'left',
            verticalAlign: 'top',
            borderWidth: 0
        },
        exporting: {
            enabled: false
        },
        series: [{
                color: '#00bfff',
                name: 'Observed',
                data: numHistory,
                stack: 'observed',
                /*tooltip: {
                    headerFormat: '',
                    pointFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>{point.master}</b> Master Instance Type: <b>{point.masterInstanceType}</b><br>' +
                        '<b>{point.worker}</b> Woker Instance Type: <b>{point.workerInstanceType}</b><br>' +
                        format,
                },*/
                stacking: 'normal',
                pointWidth: 20,
            },
            {
                color: '#e0896c',
                name: 'On-demand',
                data: ondemandPredict,
                stack: 'predicted',
                /*tooltip: {
                    headerFormat: '<b>{point.master}</b> Master Instance Type: <b>{point.masterInstanceType}</b><br>' +
                    '<b>{point.worker}</b> Woker Instance Type: <b>{point.workerInstanceType}</b><br>',
                    pointFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        format,
                },*/
                stacking: 'normal',
                pointWidth: 20,
            },
            {
                name: 'Reserved Instance',
                color: '#d3572d',
                data: riPredict,
                /*tooltip: {
                    headerFormat: '<b>{point.master}</b> Master Instance Type: <b>{point.masterInstanceType}</b><br>' +
                    '<b>{point.worker}</b> Woker Instance Type: <b>{point.workerInstanceType}</b><br>',
                    pointFormat: '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                    format,
                },*/
                stack: 'predicted',
                stacking: 'normal',
                pointWidth: 20,
            },
            {
                color: '#5cc770',
                type: 'spline',
                data: totalCountSeries,
                dashStyle: 'ShortDash',
                display: 'none',
                name: 'Capacity Allocated',
                marker : {
                    enabled: false
                },
                enableMouseTracking: false,
            }
        ],
    });
};

const setCostChart = (VMCostArray, jeriPredict) => {
    const currentTime = Date.now();
    const days = set_days;
    //const min = currentTime - (days * 24 * 60 * 60 * 1000);
    const min = currentTime;
    const max = currentTime + (days * 24 * 60 * 60 * 1000);

    awsRiCostArray = [];
    awsOndemandCostArray = [];
    gcpRiCostArray = [];
    gcpOndemandCostArray = [];
    azureRiCostArray = [];
    azureOndemandCostArray = [];
    if ("aws" in jeriPredict && "riCostPredict" in jeriPredict["aws"]) {
        awsRiCostArray = jeriPredict["aws"]["riCostPredict"];
    }
    if ("aws" in jeriPredict && "ondemandCostPredict" in jeriPredict["aws"]) {
        awsOndemandCostArray = jeriPredict["aws"]["ondemandCostPredict"];
    }
    if ("gcp" in jeriPredict && "riCostPredict" in jeriPredict["gcp"]) {
        gcpRiCostArray = jeriPredict["gcp"]["riCostPredict"];
    }
    if ("gcp" in jeriPredict && "ondemandCostPredict" in jeriPredict["gcp"]) {
        gcpOndemandCostArray = jeriPredict["gcp"]["ondemandCostPredict"];
    }
    if ("azure" in jeriPredict && "riCostPredict" in jeriPredict["azure"]) {
        azureRiCostArray = jeriPredict["azure"]["riCostPredict"];
    }
    if ("azure" in jeriPredict && "ondemandCostPredict" in jeriPredict["azure"]) {
        azureOndemandCostArray = jeriPredict["azure"]["ondemandCostPredict"];
    }
    $('#cost-chart').highcharts({
        chart: {
            height: 187,
            width: 600,
            type: 'column',
            plotBorderWidth: 1,
            marginRight: 10,
        },
        title: {
            margin: 0,
            text: 'Recommendation for Cluster Migration',
        },
        xAxis: {
            type: 'datetime',
            tickPixelInterval: 80,
            min,
            max,
        },
        yAxis: {
            title: {
                text: null,
            },
            labels: {
                format: '${value}',
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            //shared: true,
            crosshairs: true,
            useHTML: true,
            //pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: <b>{point.y:.2f}</b>',
            //headerFormat:
            //  '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
            //  '<b>{point.point.symbolName}</b><br>',
        },
        legend: {
            margin: 2,
            align: 'left',
            verticalAlign: 'top',
            borderWidth: 0,
        },
        exporting: {
            enabled: false
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                pointPadding: 0,
                groupPadding: 0.05,
                pointWidth: 15,
            }
        },
        series: [
            {
                color: '#00bfff',
                name: 'Current',
                //dashStyle: 'ShortDot',
                data: VMCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstanceType}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstanceType}</b><br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name}: <b>{point.y:.2f}</b><br/></b>',
                },
                stack: 'Current',
            },
            {
                name: 'GCP',
                color: '#8cd79a',
                dashStyle: 'ShortDot',
                data: gcpOndemandCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'GCP',
            },
            {
                name: 'GCP',
                linkedTo: ':previous',
                color: '#2c8b3e',
                dashStyle: 'ShortDot',
                data: gcpRiCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'GCP',
            },
            {
                name: 'AWS',
                color: '#c27bdf',
                dashStyle: 'ShortDot',
                data: awsOndemandCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'AWS',
            },
            {
                name: 'AWS',
                linkedTo: ':previous',
                color: '#a843d2',
                dashStyle: 'ShortDot',
                data: awsRiCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'AWS',
            },
            {
                name: 'Azure',
                color: '#f1c673',
                dashStyle: 'ShortDot',
                data: azureOndemandCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>On-demand Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'Azure',
            },
            {
                name: 'Azure',
                linkedTo: ':previous',
                color: '#ecae37',
                dashStyle: 'ShortDot',
                data: azureRiCostArray,
                display: 'none',
                tooltip: {
                    headerFormat: '',
                    pointFormat: '<b>{point.provider} ({point.region})</b><br>' +
                        '<b>{point.master}</b> Master(s): <b>{point.masterInstancetype}</b><br>' +
                        '<b>{point.worker}</b> Woker(s): <b>{point.workerInstancetype}</b><br>' +
                        '<b>{point.ondemand}</b> On-demand, <b>{point.ri}</b> 1-Year Reserved Instance<br>' +
                        '<small>{point.x:%A, %b %e, %H:%M}</small><br>' +
                        '<b>Reserved Instance Cost: <b>{point.y:.2f}</b><br/></b>' +
                        '<b><span style="color: {series.color}">\u25CF</span> {series.name} Total Cost: <b>{point.stackTotal:.2f}</b><br/></b>',
                },
                stack: 'Azure',
            },
        ],
    });
};

const setRecommendation = (prefix, recommendation) => {
    $(`#${prefix}-title`).text(recommendation["provider"]+" with RI");

    $(`#${prefix}-rec-master-region`).text(recommendation["region"]);
    $(`#${prefix}-rec-master-nodes`).text(recommendation["master"]);
    $(`#${prefix}-rec-master-size`).text(recommendation["masterInstancetype"]);
    $(`#${prefix}-rec-master-disk`).text(recommendation["masterStorageSize"]);
    $(`#${prefix}-rec-master-on-demand`).text(recommendation["masterOndemand"]);
    $(`#${prefix}-rec-master-ri`).text(recommendation["masterRi"]);

    $(`#${prefix}-rec-worker-region`).text(recommendation["region"]);
    $(`#${prefix}-rec-worker-nodes`).text(recommendation["worker"]);
    $(`#${prefix}-rec-worker-size`).text(recommendation["workerInstancetype"]);
    $(`#${prefix}-rec-worker-disk`).text(recommendation["workerStorageSize"]);
    $(`#${prefix}-rec-worker-on-demand`).text(recommendation["workerOndemand"]);
    $(`#${prefix}-rec-worker-ri`).text(recommendation["workerRi"]);

    const total = Number.parseFloat(recommendation["value"] / 7 / 24 * 730).toFixed(2)|| NaN;
    $(`#${prefix}-recommendation`).text("$" + total);
};

const dropdown = () =>{
    $('#dropdown').html('<select id="set-days" style="font-size: 14px;margin-left: 5px;font-family: "Lato", Arial, Helvetica, sans-serif;">\
    <option value="weekly">Weekly</option>\
    <option value="yearly">Yearly</option>\
  </select>\
    ')
    var activities = document.getElementById("set-days");
    activities.addEventListener("change", function() {
        if(!Isloading){
            if(activities.value==="weekly"){
                set_days=7;
            }else if (activities.value==="yearly"){
                set_days=365;
            }
            syncPage();
        }
    });
}



const setMonthlyCostChart = (VMCost, jeriPredict, currentCost, provider) => {
    $('#monthly-cost-chart').html('<p style="font-size: 20px; margin:0px; text-align: center; width: 600px; color: #333333">Cost Analysis for Cloud Services</p>\
        <div class="wrapper-in-detail">\
        <div class= "part-in-detail">\
          <h3 class="title-in-detail">Current (<span id="currently-provider">No Data</span>)</h3> \
          <div>\
            <span class="plan-in-detail">Plan: </span>\
            <div class="currently-cost-master-plan">Master\
              <span class="tooltip">\
                <div class="currently-cost-master-block">\
                  <b>Region: </b><span id="currently-cost-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="currently-cost-master-nodes">No Data</span><br />\
                  <b>Disk: </b><span id="currently-cost-master-disk">No Data</span><br />\
                  <b>Size: </b><span id="currently-cost-master-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="currently-cost-worker-plan">Worker\
              <span class="tooltip">\
                <div class="currently-cost-worker-block">\
                  <b>Region: </b><span id="currently-cost-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="currently-cost-worker-nodes">No Data</span><br />\
                  <b>Disk: </b><span id="currently-cost-worker-disk">No Data</span><br />\
                  <b>Size: </b><span id="currently-cost-worker-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price-in-detail"><span id="currently-cost-per-month">--</span><b>/month</b></p>\
        </div>\
        <div class="part-in-detail">\
          <h3 class="title-in-detail" id="first-title">No Data</h3>\
          <div>\
            <span class="plan-in-detail">Plan: </span>\
            <div class="first-rec-master-plan">Master\
              <span class="tooltip">\
                <div class="first-rec-master-block">\
                  <b>Region: </b><span id="first-rec-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="first-rec-master-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="first-rec-master-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="first-rec-master-ri">No Data</span><br />\
                  <b>Disk: </b><span id="first-rec-master-disk">No Data</span><br />\
                  <b>Size: </b><span id="first-rec-master-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="first-rec-worker-plan">Worker\
              <span class="tooltip">\
                <div class="first-rec-worker-block">\
                  <b>Region: </b><span id="first-rec-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="first-rec-worker-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="first-rec-worker-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="first-rec-worker-ri">No Data</span><br />\
                  <b>Disk: </b><span id="first-rec-worker-disk">No Data</span><br />\
                  <b>Size: </b><span id="first-rec-worker-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price-in-detail"><span id="first-recommendation">--</span><b>/month</b></p>\
        </div>\
        <div class="part-in-detail">\
          <h3 class="title-in-detail" id="second-title">No Data</h3>\
          <div>\
            <span class="plan-in-detail">Plan: </span>\
            <div class="second-rec-master-plan">Master\
              <span class="tooltip">\
                <div class="second-rec-master-block">\
                  <b>Region: </b><span id="second-rec-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="second-rec-master-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="second-rec-master-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="second-rec-master-ri">No Data</span><br />\
                  <b>Disk: </b><span id="second-rec-master-disk">No Data</span><br />\
                  <b>Size: </b><span id="second-rec-master-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="second-rec-worker-plan">Worker\
              <span class="tooltip">\
                <div class="second-rec-worker-block">\
                  <b>Region: </b><span id="second-rec-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="second-rec-worker-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="second-rec-worker-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="second-rec-worker-ri">No Data</span><br />\
                  <b>Disk: </b><span id="second-rec-worker-disk">No Data</span><br />\
                  <b>Size: </b><span id="second-rec-worker-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price-in-detail"><span id="second-recommendation">--</span><b>/month</b></p>\
        </div>\
        <div class="part-in-detail">\
          <h3 class="title-in-detail" id="third-title">No Data</h3>\
          <div>\
            <span class="plan-in-detail">Plan: </span>\
            <div class="third-rec-master-plan">Master\
              <span class="tooltip">\
                <div class="third-rec-master-block">\
                  <b>Region: </b><span id="third-rec-master-region">No Data</span><br />\
                  <b>Node(s): </b><span id="third-rec-master-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="third-rec-master-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="third-rec-master-ri">No Data</span><br />\
                  <b>Disk: </b><span id="third-rec-master-disk">No Data</span><br />\
                  <b>Size: </b><span id="third-rec-master-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
            <div class="third-rec-worker-plan">Worker\
              <span class="tooltip">\
                <div class="third-rec-worker-block">\
                  <b>Region: </b><span id="third-rec-worker-region">No Data</span><br />\
                  <b>Node(s): </b><span id="third-rec-worker-nodes">No Data</span><br />\
                  <b>On-demand: </b><span id="third-rec-worker-on-demand">No Data</span><br />\
                  <b>Reserved Instance: </b><span id="third-rec-worker-ri">No Data</span><br />\
                  <b>Disk: </b><span id="third-rec-worker-disk">No Data</span><br />\
                  <b>Size: </b><span id="third-rec-worker-size">No Data</span><br />\
                </div>\
              </span>\
            </div>\
          </div>\
          <p class="price-in-detail"><span id="third-recommendation">--</span><b>/month</b></p>\
        </div>\
      </div>');

    awsAccCost = {};
    gcpAccCost = {};
    azureAccCost = {};
    if ("aws" in jeriPredict && "accCostPredict" in jeriPredict["aws"]) {
        awsAccCost = jeriPredict["aws"]["accCostPredict"];
    }
    if ("gcp" in jeriPredict && "accCostPredict" in jeriPredict["gcp"]) {
        gcpAccCost = jeriPredict["gcp"]["accCostPredict"];
    }
    if ("azure" in jeriPredict && "accCostPredict" in jeriPredict["azure"]) {
        azureAccCost = jeriPredict["azure"]["accCostPredict"];
    }
    accCostArray = [];
    accCostArray.push(awsAccCost);
    accCostArray.push(gcpAccCost);
    accCostArray.push(azureAccCost);
    accCostArray.sort(function(x, y) {
        if (x["value"] < y["value"]) {
            return -1;
        }
        if (x["value"] > y["value"]) {
            return 1;
        }
        return 0;
    });
    var total = 0;
    if(currentCost["calculator"][0][provider.toLowerCase()][0].length!==0){
        const current = Object.assign(...currentCost["calculator"]);
        for (var tempcost in current[provider.toLowerCase()]){
            total = current[provider.toLowerCase()][tempcost]["totalcost"] + total;
        }
        var masterDisplayname = current[provider.toLowerCase()][0]["instances"]["displayname"];
        var workerDisplayname = current[provider.toLowerCase()][1]["instances"]["displayname"];


        $("#currently-provider").text(VMCost["provider"]);
        $("#currently-cost-master-region").text(VMCost["region"]);
        $("#currently-cost-master-nodes").text(VMCost["master"]);
        $("#currently-cost-master-size").text(masterDisplayname);
        $("#currently-cost-master-disk").text(VMCost["masterStorageSize"]);

        $("#currently-cost-worker-region").text(VMCost["region"]);
        $("#currently-cost-worker-nodes").text(VMCost["worker"]);
        $("#currently-cost-worker-size").text(workerDisplayname);
        $("#currently-cost-worker-disk").text(VMCost["workerStorageSize"]);
        const totalcost = Number.parseFloat(total).toFixed(2)|| NaN
        $("#currently-cost-per-month").text("$" + totalcost);
    }
    $("#currently-provider").text(VMCost["provider"]);
    $("#currently-cost-master-region").text(VMCost["region"]);
    $("#currently-cost-master-nodes").text(VMCost["master"]);
    $("#currently-cost-master-size").text(VMCost["masterInstanceType"]);
    $("#currently-cost-master-disk").text(VMCost["masterStorageSize"]);

    $("#currently-cost-worker-region").text(VMCost["region"]);
    $("#currently-cost-worker-nodes").text(VMCost["worker"]);
    $("#currently-cost-worker-size").text(VMCost["workerInstanceType"]);
    $("#currently-cost-worker-disk").text(VMCost["workerStorageSize"]);
    const totalcost = Number.parseFloat(total).toFixed(2)|| NaN
    $("#currently-cost-per-month").text("$" + totalcost);
    setRecommendation("first", accCostArray[0]);
    setRecommendation("second", accCostArray[1]);
    setRecommendation("third", accCostArray[2]);

};

const mapGPUInstance = (gpu_label) => {
    gpu_label_upper = gpu_label.toUpperCase()
    mapped_gpu = gpu_label_upper.replace("VIRTUAL WORKSTATION", "WORKSTATION").replace(/\s/g, "_");
    return `GPU_${mapped_gpu}`
}

const getPathName = () => {
    const path = window.location.pathname;
    if (path === '/clusters/new') {
        const chooseProvider = document.getElementsByClassName('provider-choices-wrapper layout-wrap layout-row');
        if (chooseProvider.length) return {
            page: 'choose-provider',
            content: null,
        };

        let started = false;
        let triggerFuc = null;
        let provider_raw = document.getElementsByClassName('provider-logo')[0].children[0].classList[0].split('-')[1];
        let os_type_raw = 'Linux';
        let volume_type_raw = 'General Purpose';
        if (provider_raw === 'gce') {
            provider_raw = 'gcp';
            os_type_raw = 'free';
            volume_type_raw = GCP_volume_type;
        } else if (provider_raw === 'aws') {
            volume_type_raw = AWS_volume_type;
        } else if (provider_raw === 'azure') {
            //TODO: need a mapping accorind to the disk size. Hardcode to standardssd-e6 for testing.
            volume_type_raw = Azure_volume_type;
        }
        const provider = provider_raw;
        const os_type = os_type_raw;

        const content = {
            provider,
            region: null,
            master: {
                os_type: os_type,
                volume_type: volume_type_raw,
                count: 0,
                disk: null,
                size: null,
                gpuinstance: null,
                gpunum: "0",
            },
            worker: {
                os_type: os_type,
                volume_type: volume_type_raw,
                count: 0,
                disk: null,
                size: null,
                gpuinstance: null,
                gpunum: "0",
            },
        };

        if (!document.forms['providerConfigModalForm']) {
            // Add page
            const region = document.querySelector('md-item:nth-child(2) > md-item-content > div:nth-child(2) > p').textContent;
            content.region = region;

            const clusterMap = {
                'Master': 'master',
                'Masters': 'master',
                'Worker': 'worker',
                'Workers': 'worker',
            };

            const elements = document.body.getElementsByClassName('ng-binding ng-scope');
            for (let i = 0; i < elements.length; i++) {
                for (let j = 0; j < elements[i].children.length; j++) {
                    if (elements[i].children[j].tagName.toUpperCase() === 'NG-PLURALIZE') {
                        const parentNode = elements[i];
                        const children = parentNode.children;
                        const clusterWithCount = children[0].innerText;
                        const count = clusterWithCount.split(' ')[0];
                        const cluster = clusterWithCount.split(' ')[1];
                        const currentObj = content[clusterMap[cluster]];
                        currentObj.count = count;

                        for (const key in children) {
                            if (children.hasOwnProperty(key)) {
                                const child = children[key];
                                const innerHTML = child.innerHTML;
                                if (innerHTML.includes('Size')) {
                                    const size = child.nextSibling.textContent.trim().toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-');
                                    currentObj.disk = size;
                                }
                                if (child.getAttribute('ng-if') === 'cluster.master_gpu_instance_size' || child.getAttribute('ng-if') === 'cluster.worker_gpu_instance_size') {
                                    for (const index in child.children) {
                                        const indexContent = child.children[index];
                                        if (indexContent.innerHTML.includes('GPU')) {
                                            const gpu = indexContent.nextSibling.textContent.trim();
                                            const matchGPU = gpu.match(/([\w ]+) \((\d+) Core\)/);
                                            currentObj.gpuinstance = mapGPUInstance(matchGPU[1]);
                                            currentObj.gpunum = matchGPU[2];
                                            //console.log(matchGPU[1]);
                                            //console.log(matchGPU[2]);
                                            break;
                                        }
                                    }
                                }
                                if (child.getAttribute('ng-if') === 'isRootDiskSizeSupported') {
                                    for (const index in child.children) {
                                        const indexContent = child.children[index];
                                        if (indexContent.innerHTML.includes('Disk')) {
                                            const disk = indexContent.nextSibling.textContent.trim().replace(/GB/g, '').trim();
                                            currentObj.size = disk;
                                            //console.log(disk);
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                        content[clusterMap[cluster]] = currentObj;
                    }
                }
            }
            return {
                page: 'new',
                content,
            };
        }

        // Edit page
        const form = document.forms['providerConfigModalForm'];
        const editFormElements = form.elements;
        const editSizes = form.getElementsByClassName('ng-scope layout-row')[0];
        const inputs = form.getElementsByClassName('spc-input-container flex-50');

        content.region = form.getElementsByTagName('md-select-value')[2].textContent || null;
        let master_disk = '';
        let master_size = 0;
        let master_gpu = '';
        let master_gpunum = 0;
        let worker_disk = '';
        let worker_size = 0;
        let worker_gpu = '';
        let worker_gpunum = 0;
        for (let i = 0; i < inputs.length; i++) {
            if (inputs[i].children[0].textContent === 'Master Size') {
                master_disk = inputs[i].children[1].children[0].textContent.trim();
            } else if (inputs[i].children[0].textContent === 'Worker Size') {
                worker_disk = inputs[i].children[1].children[0].textContent.trim();
            } else if (inputs[i].children[0].textContent.startsWith('Master Disk Size')) {
                master_size = inputs[i].children[1].getAttribute('aria-valuenow');
            } else if (inputs[i].children[0].textContent.startsWith('Worker Disk Size')) {
                worker_size = inputs[i].children[1].getAttribute('aria-valuenow');
            } else if (inputs[i].children[0].textContent.startsWith('Master GPU Addon')) {
                const gpu = inputs[i].children[1].children[0].textContent.trim();
                if (gpu != "None") {
                    const matchGPU = gpu.match(/([\w ]+) \((\d+) Core\)/);
                    master_gpu = mapGPUInstance(matchGPU[1]);
                    master_gpunum = matchGPU[2];
                    //console.log(`master_gpu: ${master_gpu}, ${master_gpunum}`);
                }
            } else if (inputs[i].children[0].textContent.startsWith('Worker GPU Addon')) {
                const gpu = inputs[i].children[1].children[0].textContent.trim();
                if (gpu != "None") {
                    const workerGPU = gpu.match(/([\w ]+) \((\d+) Core\)/);
                    worker_gpu = mapGPUInstance(workerGPU[1]);
                    worker_gpunum = workerGPU[2];
                    //console.log(`worker_gpu: ${worker_gpu}, ${worker_gpunum}`);
                }
            }
        }
        content.master = {
            os_type: os_type,
            volume_type: volume_type_raw,
            count: editFormElements[0].value || 0,
            disk: master_disk.toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-') || null,
            size: master_size || null,
            gpuinstance: master_gpu || null,
            gpunum: master_gpunum,
        };
        content.worker = {
            os_type: os_type,
            volume_type: volume_type_raw,
            count: editFormElements[1].value || 0,
            disk: worker_disk.toLowerCase().replace(/\s+/g, '-').replace(/\_/g, '-') || null,
            size: worker_size || null,
            gpuinstance: worker_gpu || null,
            gpunum: worker_gpunum,
        };

        return {
            page: 'new',
            content,
        };
    }

    const re = /\/clusters\/detail\/.+/i;
    if (path.match(re)) {
        const region = document.getElementsByClassName('cluster-location')[0].lastChild.textContent;

        let orgName = '';
        const menuChildren = document.getElementsByClassName('org-selection-menu-content')[0].children;
        for (let i = 0; i < menuChildren.length; i++) {
            const child = menuChildren[i];
            if (child.getElementsByTagName('md-icon').length && child.getElementsByClassName('org-name').length) {
                orgName = child.getElementsByClassName('org-name')[0].textContent;
            }
        }

        return {
            page: 'detail',
            content: {
                clusterID: path.split('/')[3],
                orgName,
                region,
            },
        };
    }
    return {
        page: null,
        content: window.location.pathname,
    };
};